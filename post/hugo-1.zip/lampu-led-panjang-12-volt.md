---
title: "lampu led panjang 12 volt"
description: "Jual lampu led 12 volt dc merk jimei 9 watt bisa ke aki tanpa perlu"
date: "2022-01-13"
categories:
- "bumi"
images:
- "https://s2.bukalapak.com/img/255193229/large/Lampu_Led_Strip_Pita_DC_12_Volt_Waterproof.jpg"
featuredImage: "https://ecs7.tokopedia.net/img/cache/200-square/product-1/2019/8/28/12117012/12117012_f939c2ed-d34b-4ba9-91bc-fc42d35decd5_1280_1280"
featured_image: "https://cf.shopee.co.id/file/580437e56b6d3ba455f5c9ddb28e36b9"
image: "https://cf.shopee.com.my/file/2c288125f29886c1fd6d91e0062ef26f"
---

If you are looking for led - STREET Light (PJU) » High Quality Street Light » Hiled Street you've visit to the right place. We have 35 Pics about led - STREET Light (PJU) » High Quality Street Light » Hiled Street like Jual Lampu Led Persegi Panjang 1.2 Watt 12 Volt DC di lapak H82 he82, mitsuyama Lampu led dc 12 volt panjang 60 cm 21 watt jepit aki | Shopee and also Tren Gaya 50+ Lampu Led Panjang 12 Volt. Read more:

## Led - STREET Light (PJU) » High Quality Street Light » Hiled Street

![led - STREET Light (PJU) » High Quality Street Light » Hiled Street](https://www.simplysimpler.net/image-product/img491-1425121301.jpg "Jual lampu led 12 volt dc merk jimei 9 watt bisa ke aki tanpa perlu")

<small>www.simplysimpler.net</small>

Mitsuyama lampu led dc 12 volt panjang 60 cm 21 watt jepit aki. Jimei aki

## Jual LAMPU STOPLAMP LED TRUCK VARIASI 12 DAN 24 VOLT L300 PANJANG 30CM

![Jual LAMPU STOPLAMP LED TRUCK VARIASI 12 DAN 24 VOLT L300 PANJANG 30CM](https://ecs7.tokopedia.net/img/cache/200-square/product-1/2019/8/28/12117012/12117012_f939c2ed-d34b-4ba9-91bc-fc42d35decd5_1280_1280 "Lampu led neon t8 dc 12 volt, 15 watt. panjang 60cm")

<small>www.tokopedia.com</small>

Lampu led neon t8 dc 12 volt, 15 watt. panjang 60cm. Lampu 4000k

## Lampu LED Module 6 Watt 24 Volt / LED Modul 6 Mata Besar 6W 24V

![Lampu LED Module 6 Watt 24 Volt / LED Modul 6 Mata Besar 6W 24V](https://cf.shopee.co.id/file/8138ca7499acfd50065e0b551725844d "Lampu led samsung / led modul strip 3 mata 3 watt 12 volt samsung led")

<small>shopee.co.id</small>

71+ lampu led rumah panjang. Lampu kolam renang 12w

## Jual Lampu Emergency TL Led 12V DC Terbaik Termurah – Saklawaseblog

![Jual lampu emergency TL Led 12V DC terbaik termurah – saklawaseblog](https://saklawaseblog.files.wordpress.com/2016/11/image-11110.jpg?w=250 "Jual lampu led module 3 watt 12v / led modul 3 mata besar")

<small>saklawaseblog.wordpress.com</small>

Jual lampu led modul 1.5 watt 12 volt / led module 1 mata. Jimei aki

## Jual Lampu Led Strip Pita DC 12 Volt Waterproof Di Lapak

![Jual Lampu Led Strip Pita DC 12 Volt Waterproof di Lapak](https://s2.bukalapak.com/img/255193229/large/Lampu_Led_Strip_Pita_DC_12_Volt_Waterproof.jpg "Jual lampu led persegi panjang 1.2 watt 12 volt dc di lapak h82 he82")

<small>www.bukalapak.com</small>

Lampu 4000k. Jual lampu led 12 mata 24 volt / led modul 12 mata 7w 24v

## Lampu LED Strip 4000k Natural • Prima Jaya LED

![Lampu LED Strip 4000k Natural • Prima Jaya LED](https://primajayaled.com/wp-content/uploads/2019/09/Lampu-LED-Strip-4000k-Natural-1.jpeg "Tidak ada titik cahaya lampu strip led 12v, strip lampu led panjang")

<small>primajayaled.com</small>

Jimei aki. 71+ lampu led rumah panjang

## 53+ Lampu LED 40 Watt 12 Volt

![53+ Lampu LED 40 Watt 12 Volt](https://s4.bukalapak.com/img/933470025/w-1000/Lampu_Led_TL_Neon_DC_12V___12_V___12Volt___12_Volt___5_Watt.jpg "Warna putih lampu led strip indoor cuttable panjang lampu led strip")

<small>skemaintercom.blogspot.com</small>

Lampu led neon t8 dc 12 volt, 15 watt. panjang 60cm. Lampu led motor 12 volt dc

## Tren Gaya 50+ Lampu Led Panjang 12 Volt

![Tren Gaya 50+ Lampu Led Panjang 12 Volt](https://cf.shopee.co.id/file/580437e56b6d3ba455f5c9ddb28e36b9 "Jual lampu led samsung / led modul strip 3 mata 3 watt 12 volt")

<small>gambarsaklar.blogspot.com</small>

Jual lampu led modul 1.5 watt 12 volt / led module 1 mata. Jual lampu led samsung / led modul strip 3 mata 3 watt 12 volt

## Buy Lampu LED STRIP 5050 Panjang 5m|60led/meter|merah Hijauputih Biru

![Buy Lampu LED STRIP 5050 panjang 5m|60led/meter|merah hijauputih biru](http://gdetail.image-gmkt.com/873/604506136/2014/12/eac36451-48e9-4094-ac02-2bce36ad0480.jpg "Jual lampu led panjang murah")

<small>www.bydeals.net</small>

Konsep 28+ lampu panjang berapa watt. Mitsuyama lampu led dc 12 volt panjang 60 cm 21 watt jepit aki

## Lampu LED Neon T8 DC 12 Volt, 15 Watt. Panjang 60cm

![Lampu LED Neon T8 DC 12 volt, 15 watt. Panjang 60cm](http://toko28.com/_image/peralatan/dc/lampu-led-12volt.jpg "Jual lampu stoplamp led truck variasi 12 dan 24 volt l300 panjang 30cm")

<small>www.toko28.com</small>

Lampu panjang persegi penerangan. 71+ lampu led rumah panjang

## Jual Lampu Led Persegi Panjang 1.2 Watt 12 Volt DC Di Lapak H82 He82

![Jual Lampu Led Persegi Panjang 1.2 Watt 12 Volt DC di lapak H82 he82](https://s3.bukalapak.com/img/37593073/w-300/LED_SAMSUNG_12V-1.JPG "Jual lampu kolam renang led 12w 12 watt 12 volt lampu kolam renang led")

<small>www.bukalapak.com</small>

Lampu persegi penerangan alat elektronik. Jimei merk aki jual bukalapak

## Jual Lampu LED 12 Volt DC Merk JIMEI 9 Watt Bisa Ke Aki Tanpa Perlu

![Jual Lampu LED 12 Volt DC Merk JIMEI 9 watt Bisa ke aki tanpa perlu](https://s2.bukalapak.com/img/7620118721/w-1000/Lampu_LED_12_Volt_DC_Merk_JIMEI_9_watt__Bisa_ke_aki_tanpa_pe.png "Lampu 4000k")

<small>www.bukalapak.com</small>

Lampu strip led emitting sisi fleksibel smd 5050 5m 300 leds 60 leds. Jimei merk aki jual bukalapak

## Jual Lampu SAMSUNG LED Modul 5730 SMD 12V DC 3 Mata 12 Volt Module

![Jual Lampu SAMSUNG LED Modul 5730 SMD 12V DC 3 Mata 12 Volt Module](https://ecs7.tokopedia.net/img/cache/700/VqbcmM/2020/9/23/901964ff-41f4-4a75-bfab-d0bf319b055c.jpg "Lampu led neon t8 dc 12 volt, 15 watt. panjang 60cm")

<small>www.tokopedia.com</small>

Tidak ada titik cahaya lampu strip led 12v, strip lampu led panjang. Lampu watt

## Lampu LED Samsung / LED Modul Strip 3 Mata 3 Watt 12 Volt Samsung Led

![Lampu LED Samsung / LED Modul Strip 3 Mata 3 Watt 12 Volt Samsung Led](https://cf.shopee.co.id/file/4a84f4565c8d25d5f4fffcbf0cdb9127 "Jual lampu stoplamp led truck variasi 12 dan 24 volt l300 panjang 30cm")

<small>shopee.co.id</small>

Lampu t4 9watt. Jual lampu emergency tl led 12v dc terbaik termurah – saklawaseblog

## Jual Lampu Led Persegi Panjang 1.2 Watt 12 Volt DC Di Lapak H82 He82

![Jual Lampu Led Persegi Panjang 1.2 Watt 12 Volt DC di lapak H82 he82](https://s3.bukalapak.com/img/39393073/w-1000/LED_SAMSUNG_12V-0.JPG "Lampu bohlam utamas")

<small>www.bukalapak.com</small>

Lampu strip led emitting sisi fleksibel smd 5050 5m 300 leds 60 leds. Jual lampu led modul 1.5 watt 12 volt / led module 1 mata

## Konsep 28+ Lampu Panjang Berapa Watt

![Konsep 28+ Lampu Panjang Berapa Watt](https://s4.bukalapak.com/img/930024749/w-1000/lampu_TL_LED_kecil_60_cm_8_watt_cocok_u_gerobak_etalase_dll.png "Jual lampu kolam renang led 12w 12 watt 12 volt lampu kolam renang led")

<small>desainatapplafonminimalis.blogspot.com</small>

Jual lampu led module 3 watt 12v / led modul 3 mata besar. Lampu panjang 60led biru hias

## Lampu Strip LED Emitting Sisi Fleksibel Smd 5050 5m 300 Leds 60 Leds

![Lampu Strip LED Emitting Sisi Fleksibel Smd 5050 5m 300 Leds 60 Leds](http://indonesian.smdledstriplight.com/photo/pl24740354-flexible_side_emitting_led_strip_lights_smd_5050_5m_300_leds_60_leds_m_continuous_length.jpg "Lampu strip led emitting sisi fleksibel smd 5050 5m 300 leds 60 leds")

<small>indonesian.smdledstriplight.com</small>

Lampu t4 9watt. Volt 12volt tl bukalapak

## Lampu Led Motor 12 Volt DC - Lampu Sorot Di Lapak Electronics Madness

![Lampu Led Motor 12 Volt DC - Lampu Sorot di Lapak Electronics Madness](https://s0.bukalapak.com/img/04069561/large/LAMPU_SPOT__LED_12V_9-12WATT.jpg "Lampu kolam renang 12w")

<small>www.bukalapak.com</small>

Jual lampu led samsung / led modul strip 3 mata 3 watt 12 volt. Lampu led motor 12 volt dc

## Warna Putih Lampu LED Strip Indoor Cuttable Panjang Lampu LED Strip

![Warna Putih Lampu LED Strip Indoor Cuttable Panjang Lampu LED Strip](http://indonesian.led-neonlights.com/photo/pl22969482-white_color_indoor_led_strip_lights_cuttable_long_led_light_strips_for_home.jpg "Tidak ada titik cahaya lampu strip led 12v, strip lampu led panjang")

<small>indonesian.led-neonlights.com</small>

Jual lampu led persegi panjang 1.2 watt 12 volt dc di lapak h82 he82. 7w utamas

## 71+ Lampu Led Rumah Panjang

![71+ Lampu Led Rumah Panjang](https://s3.bukalapak.com/img/8681088383/w-1000/Lampu_Neon_Panjang_Strip_Tabung_LED_USB_Belajar_Kerja_Rumah_.jpg "Jual lampu led modul 1.5 watt 12 volt / led module 1 mata")

<small>bebaslistrikd.blogspot.com</small>

Jimei aki. Jual lampu samsung led modul 5730 smd 12v dc 3 mata 12 volt module

## Lampu LED Neon T8 DC 12 Volt, 15 Watt. Panjang 60cm

![Lampu LED Neon T8 DC 12 volt, 15 watt. Panjang 60cm](http://toko28.com/_image/peralatan/dc/lampu-hemat-energi.jpg "Jual lampu led 12 volt dc merk jimei 9 watt bisa ke aki tanpa perlu")

<small>www.toko28.com</small>

Lampu strip led emitting sisi fleksibel smd 5050 5m 300 leds 60 leds. Cuttable lampu putih panjang strisce rumah neonlights lunghe bianche fluorescenti largas tira

## Jual Lampu LED Samsung / LED Modul Strip 3 Mata 3 Watt 12 Volt

![Jual Lampu LED Samsung / LED Modul Strip 3 Mata 3 Watt 12 Volt](https://images.tokopedia.net/img/cache/500-square/product-1/2019/7/9/8469339/8469339_ed0364a8-e207-47ec-80c8-9e446fd5b8bb_2048_2048?ect=4g "Jual lampu led panjang murah")

<small>www.tokopedia.com</small>

Jual lampu led panjang murah. Lampu modul biru utamas

## 71+ Lampu Led Rumah Panjang

![71+ Lampu Led Rumah Panjang](https://ecs7.tokopedia.net/img/cache/700/product-1/2019/3/18/2718427/2718427_469f52b9-1e0b-44bf-b66d-59d8d1773d86_1080_1080.jpg "Jimei aki")

<small>bebaslistrikd.blogspot.com</small>

Tidak ada titik cahaya lampu strip led 12v, strip lampu led panjang. Lampu led strip 4000k natural • prima jaya led

## Jual Lampu LED 12 Mata 24 Volt / LED Modul 12 Mata 7W 24V - Putih

![Jual Lampu LED 12 Mata 24 Volt / LED Modul 12 Mata 7W 24V - Putih](https://ecs7.tokopedia.net/img/cache/700/product-1/2020/8/3/8469339/8469339_feb9bc09-ea0b-445d-8ceb-db442a8978ba_1024_1024 "Jual lampu led modul 1.5 watt 12 volt / led module 1 mata")

<small>www.tokopedia.com</small>

Jual lampu led 12 mata 24 volt / led modul 12 mata 7w 24v. 71+ lampu led rumah panjang

## Jual Lampu LED Modul 1.5 Watt 12 Volt / LED Module 1 Mata - Biru

![Jual Lampu LED Modul 1.5 Watt 12 Volt / LED Module 1 Mata - Biru](https://ecs7.tokopedia.net/img/cache/700/product-1/2019/8/13/8469339/8469339_1dfba004-97df-46cd-acbf-46fb3789f197_1973_1973 "Lampu modul biru utamas")

<small>www.tokopedia.com</small>

Jual lampu led module 3 watt 12v / led modul 3 mata besar. Lampu led neon t8 dc 12 volt, 15 watt. panjang 60cm

## Tidak Ada Titik Cahaya Lampu Strip LED 12V, Strip Lampu LED Panjang

![Tidak Ada Titik Cahaya Lampu Strip LED 12V, Strip Lampu LED Panjang](http://indonesian.smdledstriplight.com/photo/pl20655007-no_light_spots_12v_led_strip_lights_long_led_light_strips_for_rigid_bar.jpg "Gantung plafon sumber")

<small>indonesian.smdledstriplight.com</small>

Mitsuyama lampu led dc 12 volt panjang 60 cm 21 watt jepit aki. Lampu watt

## Lampu LED 12 Volt DC Merk JIMEI 9 Watt ( Bisa Ke Aki Tanpa Perlu

![Lampu LED 12 Volt DC Merk JIMEI 9 watt ( Bisa ke aki tanpa perlu](https://s2.bukalapak.com/img/7200933621/large/Lampu_LED_12_Volt_DC_Merk_JIMEI_9_watt___Bisa_ke_aki_tanpa_p.jpg "Lampu 4000k")

<small>www.bukalapak.com</small>

Lampu persegi penerangan alat elektronik. Tren gaya 50+ lampu led panjang 12 volt

## Tren Gaya 50+ Lampu Led Panjang 12 Volt

![Tren Gaya 50+ Lampu Led Panjang 12 Volt](https://i2.wp.com/www.tokoelektroniksurabaya.com/wp-content/uploads/2020/02/Lampu-LED-Modul-Strip-1-Mata-12-Volt-3.jpg?fit=700%2C700&amp;ssl=1 "7w utamas")

<small>gambarsaklar.blogspot.com</small>

Lampu modul biru utamas. Lampu led neon t8 dc 12 volt, 15 watt. panjang 60cm

## Mitsuyama Lampu Led Dc 12 Volt Panjang 60 Cm 21 Watt Jepit Aki | Shopee

![mitsuyama Lampu led dc 12 volt panjang 60 cm 21 watt jepit aki | Shopee](https://cf.shopee.co.id/file/ed3d075681774aa7dc31ad75d00064d4 "Jual lampu stoplamp led truck variasi 12 dan 24 volt l300 panjang 30cm")

<small>shopee.co.id</small>

Lampu modul utamas. Lampu led motor 12 volt dc

## 53+ Lampu LED 40 Watt 12 Volt

![53+ Lampu LED 40 Watt 12 Volt](https://s1.bukalapak.com/img/6064960521/w-1000/Lampu_LED_12_Volt_DC_Merk_JIMEI_4_watt__Bisa_ke_aki_tanpa_pe.png "Tren gaya 50+ lampu led panjang 12 volt")

<small>skemaintercom.blogspot.com</small>

7w utamas. Jual lampu led 12 mata 24 volt / led modul 12 mata 7w 24v

## Jual Lampu Kolam Renang Led 12w 12 Watt 12 Volt Lampu Kolam Renang Led

![Jual lampu kolam renang led 12w 12 watt 12 volt lampu kolam renang led](https://ecs7.tokopedia.net/img/cache/700/attachment/2018/8/27/153537047896899/153537047896899_8e4c6fce-43e4-494c-9e69-cea25b4d8763.png "Jual lampu led 12 volt dc merk jimei 9 watt bisa ke aki tanpa perlu")

<small>www.tokopedia.com</small>

Jual lampu kolam renang led 12w 12 watt 12 volt lampu kolam renang led. Jual lampu led panjang murah

## Jual Lampu Led Panjang Murah - Harga Terbaru 2021

![Jual Lampu Led Panjang Murah - Harga Terbaru 2021](https://ecs7-p.tokopedia.net/img/cache/200-square/VqbcmM/2020/11/12/188b2025-be2d-4caa-b54c-c1b2737102e9.jpg "Lampu panjang persegi penerangan")

<small>www.tokopedia.com</small>

Tidak ada titik cahaya lampu strip led 12v, strip lampu led panjang. Lampu modul mata module smd putih

## Jual Lampu LED 12 Volt DC Merk JIMEI 9 Watt Bisa Ke Aki Tanpa Perlu

![Jual Lampu LED 12 Volt DC Merk JIMEI 9 watt Bisa ke aki tanpa perlu](https://s2.bukalapak.com/img/2531118721/w-1000/Lampu_LED_12_Volt_DC_Merk_JIMEI_9_watt__Bisa_ke_aki_tanpa_pe.png "Jual lampu led 12 mata 24 volt / led modul 12 mata 7w 24v")

<small>www.bukalapak.com</small>

Konsep 28+ lampu panjang berapa watt. Jual lampu led strip pita dc 12 volt waterproof di lapak

## Lampu Led Panjang Berapa Watt - LAMPUTASOR

![Lampu Led Panjang Berapa Watt - LAMPUTASOR](https://cf.shopee.com.my/file/2c288125f29886c1fd6d91e0062ef26f "Rigid titik")

<small>lamputasor.blogspot.com</small>

Lampu termurah. Lampu led neon t8 dc 12 volt, 15 watt. panjang 60cm

## Jual Lampu LED Module 3 Watt 12V / LED Modul 3 Mata Besar - Merah

![Jual Lampu LED Module 3 Watt 12V / LED Modul 3 Mata Besar - Merah](https://ecs7.tokopedia.net/img/cache/700/product-1/2019/10/12/8469339/8469339_22c7c813-06f9-42ec-9a73-0b603055565c_2048_2048 "Jual lampu led panjang murah")

<small>www.tokopedia.com</small>

Lampu led panjang berapa watt. 71+ lampu led rumah panjang

Lampu led samsung / led modul strip 3 mata 3 watt 12 volt samsung led. Lampu pita. Tren gaya 50+ lampu led panjang 12 volt
