---
title: "membuat petasan"
description: "Cara membuat petasan dari busi motor"
date: "2021-12-19"
categories:
- "bumi"
images:
- "https://i.ytimg.com/vi/KHh8OSsxiAU/maxresdefault.jpg"
featuredImage: "https://i.ytimg.com/vi/vvUCdO15pLo/maxresdefault.jpg"
featured_image: "https://i.ytimg.com/vi/bTiAS9LBiqY/hqdefault.jpg"
image: "https://i.ytimg.com/vi/bpoJOAt-A6Q/hqdefault.jpg"
---

If you are looking for Membuat petasan dari pucuk pulpen - YouTube you've came to the right place. We have 35 Pics about Membuat petasan dari pucuk pulpen - YouTube like CARA MEMBUAT PETASAN KERTAS SANGAT MUDAH - YouTube, Membuat petasan dari korek - YouTube and also Cara Membuat Petasan Roket Sendiri - YouTube. Read more:

## Membuat Petasan Dari Pucuk Pulpen - YouTube

![Membuat petasan dari pucuk pulpen - YouTube](https://i.ytimg.com/vi/NlX5bc_GOoc/maxresdefault.jpg "Tradisi bulan puasa membuat petasan dari karbit")

<small>www.youtube.com</small>

Cara membuat petasan. Cara membuat petasan dari bolpoin(pulpen)

## Cara Membuat Petasan Kertas Baik Dan Benar - YouTube

![cara membuat petasan kertas baik dan benar - YouTube](https://i.ytimg.com/vi/GfXztcavK7o/maxresdefault.jpg "Minecraft membuat petasan (part 2)")

<small>www.youtube.com</small>

Membuat petasan. Cara membuat petasan kertas sangat mudah

## Membuat Petasan Dari Busi = Part 3 - YouTube

![Membuat petasan dari busi = Part 3 - YouTube](https://i.ytimg.com/vi/O1EO0VgkZlY/maxresdefault.jpg "Membuat senapan petasan tahun 90 an dari bambu")

<small>www.youtube.com</small>

Cara membuat petasan. Mr.yoyong: membuat petasan rakitan spiritus

## Cara Membuat Petasan Lebaran(Mudah) - YouTube

![Cara Membuat Petasan Lebaran(Mudah) - YouTube](https://i.ytimg.com/vi/ZjiAWC0xTL0/maxresdefault.jpg "Tips membuat mercon sederhana")

<small>www.youtube.com</small>

Membuat petasan. Cara membuat petasan lebaran(mudah)

## Membuat Petasan - YouTube

![Membuat petasan - YouTube](https://i.ytimg.com/vi/JSUHpKgClm8/hqdefault.jpg "Komputer &amp; mobile: cara membuat petasan kaleng")

<small>www.youtube.com</small>

Karbit petasan. Cara membuat petasan dengan mudah dan cepat

## Cara Membuat Petasan Kertas - YouTube

![Cara membuat petasan kertas - YouTube](https://i.ytimg.com/vi/vvUCdO15pLo/maxresdefault.jpg "Mercon petasan")

<small>www.youtube.com</small>

Karbit petasan. Membuat petasan dari busi = part 3

## Cara Membuat Petasan Di Minecraft - YouTube

![Cara membuat petasan di minecraft - YouTube](https://i.ytimg.com/vi/XMlwe5NpVh0/maxresdefault.jpg "Cara membuat petasan")

<small>www.youtube.com</small>

Cara membuat petasan kertas sangat mudah. Cara membuat petasan

## Galery Catatan: Cara Membuat Petasan Rakitan Kaleng Bekas Dengan Spirtus

![Galery Catatan: Cara Membuat Petasan Rakitan Kaleng Bekas Dengan Spirtus](http://1.bp.blogspot.com/-0YnxMJoulV0/U7WYtLJkM3I/AAAAAAAAB9w/eqhS-LSOUA0/s1600/sarangan.jpg "Membuat petasan sambil ngudud")

<small>galerycatatan.blogspot.com</small>

Kertas petasan. Tutorial membuat petasan dari busi bekas!!!!

## Membuat Petasan Dari Korek - YouTube

![Membuat petasan dari korek - YouTube](https://i.ytimg.com/vi/b0ld1vlP7yk/maxresdefault.jpg "Minecraft membuat petasan (part 2)")

<small>www.youtube.com</small>

Kertas petasan. Membuat petasan

## Cara Membuat Petasan Spirtus Part 1 - YouTube

![Cara membuat petasan spirtus part 1 - YouTube](https://i.ytimg.com/vi/bTiAS9LBiqY/hqdefault.jpg "Membuat petasan")

<small>www.youtube.com</small>

Cara membuat petasan spirtus part 1. Mr.yoyong: membuat petasan rakitan spiritus

## Cara Membuat Petasan Roket Sendiri - YouTube

![Cara Membuat Petasan Roket Sendiri - YouTube](https://i.ytimg.com/vi/kEhXpw3EKh4/hqdefault.jpg "Cara membuat petasan")

<small>www.youtube.com</small>

Cara membuat petasan roket dari korek api. Cara membuat petasan dari bolpoin(pulpen)

## Cara Membuat Alat Petasan Otomatis - YouTube

![Cara membuat alat petasan otomatis - YouTube](https://i.ytimg.com/vi/c8OVjnO28qQ/maxresdefault.jpg "Membuat senapan petasan tahun 90 an dari bambu")

<small>www.youtube.com</small>

Cara membuat petasan kertas. Cara membuat pistol petasan / dompis dari kayu

## Tradisi Bulan Puasa Membuat Petasan Dari Karbit - YouTube

![Tradisi bulan puasa membuat petasan dari karbit - YouTube](https://i.ytimg.com/vi/Fu26uz3uSbw/maxresdefault.jpg "Petasan spirtus membuat kaleng meriam rakitan saringan")

<small>www.youtube.com</small>

Mr.yoyong: membuat petasan rakitan spiritus. Cara membuat petasan

## Komputer &amp; Mobile: Cara Membuat Petasan Kaleng

![Komputer &amp; Mobile: Cara membuat Petasan Kaleng](http://2.bp.blogspot.com/-zBmkdt5Y8X0/UrXerNyBojI/AAAAAAAAALs/LY2hFQqrpfI/s1600/Untitled-5a.jpg "Experiment membuat petasan")

<small>mhmdnet.blogspot.com</small>

Cara membuat petasan di minecraft. Cara membuat petasan roket sendiri

## CARA MEMBUAT PETASAN DARI BUSI MOTOR - YouTube

![CARA MEMBUAT PETASAN DARI BUSI MOTOR - YouTube](https://i.ytimg.com/vi/bpoJOAt-A6Q/hqdefault.jpg "Cara membuat petasan spirtus part 1")

<small>www.youtube.com</small>

Membuat petasan sambil ngudud. Cara membuat petasan kertas baik dan benar

## TONO-BLOG: CARA MEMBUAT PETASAN TERBESAR DI DUNIA

![TONO-BLOG: CARA MEMBUAT PETASAN TERBESAR DI DUNIA](http://1.bp.blogspot.com/-bNeUgYNqhqA/TlYdQzfFrOI/AAAAAAAAAFs/4V02btvL5tw/s1600/gm3.jpg "Tradisi bulan puasa membuat petasan dari karbit")

<small>ucing-gerig.blogspot.com</small>

Tradisi bulan puasa membuat petasan dari karbit. Kertas petasan

## Cara Membuat Pistol Petasan / Dompis Dari Kayu - YouTube

![Cara Membuat Pistol Petasan / Dompis Dari Kayu - YouTube](https://i.ytimg.com/vi/QYvjGnfbHqw/hqdefault.jpg "Cara membuat petasan")

<small>www.youtube.com</small>

Cara membuat petasan. Cara membuat petasan spirtus part 1

## Cara Membuat Petasan Roket Dari Korek Api - YouTube

![cara membuat petasan roket dari korek api - YouTube](https://i.ytimg.com/vi/oAfIEAWjv_8/hqdefault.jpg "Cara membuat petasan")

<small>www.youtube.com</small>

Membuat senapan petasan tahun 90 an dari bambu. Tono-blog: cara membuat petasan terbesar di dunia

## Tips Membuat Mercon Sederhana | NOTICE BLOGGER

![Tips Membuat Mercon Sederhana | NOTICE BLOGGER](https://1.bp.blogspot.com/-GeOK_QsKls0/U65RJNQySAI/AAAAAAAAAaw/Wsung5RtZbA/w1200-h630-p-k-no-nu/Petasan-Korek-560x314.png "Cara membuat petasan roket dari korek api")

<small>terupdatedanterbaru.blogspot.com</small>

Membuat senapan petasan tahun 90 an dari bambu. Cara membuat petasan lebaran(mudah)

## CARA MEMBUAT PETASAN KERTAS SANGAT MUDAH - YouTube

![CARA MEMBUAT PETASAN KERTAS SANGAT MUDAH - YouTube](https://i.ytimg.com/vi/HQDOMNxtlWc/maxresdefault.jpg "Komputer &amp; mobile: cara membuat petasan kaleng")

<small>www.youtube.com</small>

Cara membuat petasan spirtus dari paralon 16 images. Cara membuat petasan kertas sederhana

## Mr.yoyong: Membuat Petasan Rakitan Spiritus

![mr.yoyong: Membuat petasan rakitan spiritus](https://3.bp.blogspot.com/-9tGJYo_sVKs/UeoRP-ItkPI/AAAAAAAAAJw/Opm3FN_ebAI/s1600/20072013610.jpg "Cara membuat petasan di minecraft")

<small>gondheng.blogspot.com</small>

Cara membuat petasan dengan mudah dan cepat. Membuat senapan petasan tahun 90 an dari bambu

## Galery Catatan: Cara Membuat Petasan Rakitan Kaleng Bekas Dengan Spirtus

![Galery Catatan: Cara Membuat Petasan Rakitan Kaleng Bekas Dengan Spirtus](http://3.bp.blogspot.com/-1K5Wsi5KQ7A/UfarpK1aEgI/AAAAAAAABew/exrcNAZM83E/s1600/Petasan+Rakitan+dengan+Kaleng+bekas.jpg "Cara membuat petasan kertas sederhana")

<small>galerycatatan.blogspot.com</small>

Tono-blog: cara membuat petasan terbesar di dunia. Cara membuat petasan di minecraft

## Cara Membuat Petasan - YouTube

![cara membuat petasan - YouTube](https://i.ytimg.com/vi/cyR0XsHy7Ow/maxresdefault.jpg "Kertas petasan gimana ane dlam idul fitri")

<small>www.youtube.com</small>

Cara membuat pistol petasan / dompis dari kayu. Mercon petasan

## Tutorial Membuat Petasan Dari Busi Bekas!!!! - YouTube

![Tutorial membuat petasan dari busi bekas!!!! - YouTube](https://i.ytimg.com/vi/tlm7gv8ZjWM/maxresdefault.jpg "Mercon petasan")

<small>www.youtube.com</small>

Cara membuat petasan roket sendiri. Cara membuat petasan dari bolpoin(pulpen)

## CARA MEMBUAT PETASAN DENGAN MUDAH DAN CEPAT - YouTube

![CARA MEMBUAT PETASAN DENGAN MUDAH DAN CEPAT - YouTube](https://i.ytimg.com/vi/wjj4J4MQi3g/maxresdefault.jpg "Kertas petasan cara membuat")

<small>www.youtube.com</small>

Galery catatan: cara membuat petasan rakitan kaleng bekas dengan spirtus. Kertas petasan

## Experiment MEMBUAT PETASAN - YouTube

![Experiment MEMBUAT PETASAN - YouTube](https://i.ytimg.com/vi/yr5ZhdQyEPc/maxresdefault.jpg "Cara membuat petasan dengan mudah dan cepat")

<small>www.youtube.com</small>

Kaleng petasan penjelasan komputer. Karbit petasan

## MEMBUAT PETASAN SAMBIL NGUDUD - YouTube

![MEMBUAT PETASAN SAMBIL NGUDUD - YouTube](https://i.ytimg.com/vi/Yyw5azehoW4/maxresdefault.jpg "Cara membuat petasan")

<small>www.youtube.com</small>

Experiment membuat petasan. Cara membuat petasan roket dari korek api

## Cara Membuat Petasan Kertas Sederhana

![cara membuat petasan kertas sederhana](http://1.bp.blogspot.com/-IzLs68Ep3Gg/UezuFGE846I/AAAAAAAAABY/qP_sG77GItE/s1600/IMG00309-20130713-2337.jpg "Kaleng petasan penjelasan komputer")

<small>buatmercon.blogspot.com</small>

Experiment membuat petasan. Tips membuat mercon sederhana

## Membuat Senapan Petasan Tahun 90 An Dari Bambu - YouTube

![Membuat senapan petasan tahun 90 an dari bambu - YouTube](https://i.ytimg.com/vi/7QumZ4CeoWw/maxresdefault.jpg "Cara membuat petasan roket dari korek api")

<small>www.youtube.com</small>

Mr.yoyong: membuat petasan rakitan spiritus. Petasan spirtus membuat kaleng meriam rakitan saringan

## Minecraft Membuat Petasan (Part 2) - YouTube

![Minecraft Membuat Petasan (Part 2) - YouTube](https://i.ytimg.com/vi/7S2u1xcHpZ4/maxresdefault.jpg "Cara membuat petasan kertas baik dan benar")

<small>www.youtube.com</small>

Cara membuat pistol petasan / dompis dari kayu. Karbit petasan

## Membuat Petasan - YouTube

![Membuat petasan - YouTube](https://i.ytimg.com/vi/lwg1Sz8RlD0/maxresdefault.jpg "Kertas petasan cara membuat")

<small>www.youtube.com</small>

Kaleng petasan penjelasan komputer. Membuat petasan

## Cara Membuat Petasan - YouTube

![Cara membuat petasan - YouTube](https://i.ytimg.com/vi/KHh8OSsxiAU/maxresdefault.jpg "Mercon petasan")

<small>www.youtube.com</small>

Tips membuat mercon sederhana. Galery catatan: cara membuat petasan rakitan kaleng bekas dengan spirtus

## Cara Membuat Petasan - YouTube

![Cara membuat petasan - YouTube](https://i.ytimg.com/vi/hycmjPGrTC4/maxresdefault.jpg "Cara membuat petasan")

<small>www.youtube.com</small>

Cara membuat pistol petasan / dompis dari kayu. Cara membuat petasan kertas

## Cara Membuat Petasan Dari Bolpoin(pulpen) - YouTube

![Cara Membuat Petasan Dari Bolpoin(pulpen) - YouTube](https://i.ytimg.com/vi/Whrsw8_xtKQ/maxresdefault.jpg "Galery catatan: cara membuat petasan rakitan kaleng bekas dengan spirtus")

<small>www.youtube.com</small>

Cara membuat petasan lebaran(mudah). Cara membuat petasan dengan mudah dan cepat

## Cara Membuat Petasan Spirtus Dari Paralon 16 Images - Perancangan

![Cara Membuat Petasan Spirtus Dari Paralon 16 Images - Perancangan](https://aromarasa.com/wp-content/uploads/2021/04/cara-membuat-es-campur-spesial-enak-tanpa-ribet.jpg "Experiment membuat petasan")

<small>crm2.oncoreleads.com</small>

Kaleng petasan penjelasan komputer. Cara membuat petasan dengan mudah dan cepat

Cara membuat petasan lebaran(mudah). Cara membuat petasan kertas baik dan benar. Cara membuat petasan roket dari korek api
