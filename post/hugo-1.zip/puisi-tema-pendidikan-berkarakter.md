---
title: "puisi tema pendidikan berkarakter"
description: "Puisi pantun lingkungan"
date: "2022-07-08"
categories:
- "bumi"
images:
- "https://1.bp.blogspot.com/-dmtwaHCk0n4/W5P1ZfMKmdI/AAAAAAAAEXo/Tyj-koOxsq4G9N_ITXZkUCS8ujRToL5ygCLcBGAs/s1600/kata.jpg"
featuredImage: "https://1.bp.blogspot.com/-8IO-EJ4QcQs/X7MBzv82TwI/AAAAAAAAEPk/NxU2fHM7uREo64VGjjX4BNQIQ2vP8k4UgCLcBGAsYHQ/s2048/puisi-pendidikan-singkat%2B%25284%2529.jpg"
featured_image: "https://jejakpublisher.com/storage/2017/11/Poster-Puisi-Pendidikan.jpg"
image: "https://lh5.googleusercontent.com/proxy/KTCb4kU2d9sS8iY4YASaVW5sG7S7kGLeFX2s29chEiXjrNGCtPsa3KDbAjAScWW_fLYYQteT4tsgB7a6b0Hcw5iW1p9w11c2zaMbLQO-B88FDmfpJ4OJGV49RY9HwP7sT53bBHXUvOMoIvmgbRSP"
---

If you are searching about Baru 27+ Puisi Pendek Tentang Sekolah you've visit to the right web. We have 35 Pictures about Baru 27+ Puisi Pendek Tentang Sekolah like Contoh Puisi Bertema Hari Pendidikan Nasional - Terkait Pendidikan, Puisi pendidikan and also Kumpulan Puisi Tema Pendidikan, Cocok untuk Referensi Tugas Sekolah. Here you go:

## Baru 27+ Puisi Pendek Tentang Sekolah

![Baru 27+ Puisi Pendek Tentang Sekolah](https://4.bp.blogspot.com/-2Bw44n0aC3Y/WuA6TO83L9I/AAAAAAAAC-0/YN2GfRw92EcsIOhhGZ56LJZXQ86q-KIYwCEwYBhgL/s1600/puisi2Bjawa.jpg "Puisi guruku ilmu diriku chairil anwar karya menginspirasi pantun terimakasih rakyat tersayang bacaa kurniawan adalah dasar")

<small>pemandanganindahh.blogspot.com</small>

10+ ide puisi tentang lingkungan sekolah 2 bait. Puisi pendidikan bertema

## Contoh Puisi Bali Anyar Tema Pendidikan - KT Puisi

![Contoh Puisi Bali Anyar Tema Pendidikan - KT Puisi](https://imgv2-1-f.scribdassets.com/img/document/258247835/original/f041111412/1563815507?v=1 "Kumpulan puisi tema pendidikan, cocok untuk referensi tugas sekolah")

<small>ktpuisi.blogspot.com</small>

Mutiara motivasi puisi ucapan pensiun perpisahan kutipan bbm bijak singkat murid persaraan quotemutiara naskah nasional seniman bermutu siswa hikmah maafkan. Geguritan puisi bertema teks brainly prosedur majas singkat implications immunosenescence responses accine elicited maaf kalo salah

## Contoh Puisi Bertema Hari Pendidikan Nasional - Terkait Pendidikan

![Contoh Puisi Bertema Hari Pendidikan Nasional - Terkait Pendidikan](https://lh6.googleusercontent.com/proxy/yc4q2jvl0ZORxPcG-HacyiaygJBSvojaqMG15vM0YGbS9B-t_KTxlfC8KDaxyYLNArrlP4egkNWhyREk3NrYbdlIF5xmMnqaKLup7IjVEdgULHgme7EuJ8bXLqO2ITQu6kh7LdIrVKssiJZ2RqS0ow=w1200-h630-p-k-no-nu "Puisi contoh pendidikan tentang syair sahabat pendek besari fiersa singkat anekdot cikimm")

<small>terkaitpendidikan.blogspot.com</small>

Diriku menginspirasi dunia: puisi hari guru. Puisi pendidikan bertema

## Puisi Bertema Pendidikan Karya Chairil Anwar - Bacaan Siswa

![Puisi Bertema Pendidikan Karya Chairil Anwar - Bacaan Siswa](https://imgv2-1-f.scribdassets.com/img/document/201866984/original/8896bde4fa/1574117673?v=1 "Lomba cipta puisi nasional bertema “pendidikan” bersama jejak publisher")

<small>bacaansiswaku.blogspot.com</small>

Kumpulan puisi tema pendidikan, cocok untuk referensi tugas sekolah. Puisi sekolahku smp

## Diriku Menginspirasi Dunia: Puisi Hari Guru

![Diriku menginspirasi dunia: Puisi Hari Guru](http://3.bp.blogspot.com/-9kgHdnCYBSc/VUBtWSm7gMI/AAAAAAAAAA4/4mJqMNEXfxw/s1600/puisi%2Bguru.jpg "Puisi sahabat macam majalah pendek bait sastra titikdua istilah antologi teks keindahan pemandangan peliharaan ekspresi judul berbentuk gubahan bertema binatang")

<small>inspirasikehidupanduniaku.blogspot.com</small>

Puisi kumpulan anyar pendek lingkungan pengarangnya alam pendidikan unsur intrinsiknya kemerdekaan adiwiyata chairil anwar kemanusiaan pantun sunda. Puisi singkat

## Lomba Mengarang Dan Membaca Puisi Dengan Tema &quot;BANGGA JADI POLISI

![Lomba Mengarang dan Membaca Puisi dengan tema &quot;BANGGA JADI POLISI](https://2.bp.blogspot.com/-Sko0Iko_G9c/Wvk8QvD3eoI/AAAAAAAADTY/SvE5lr4yBx0re4GyHl4WdOKd_WKf3aqbQCLcBGAs/s1600/WhatsApp%2BImage%2B2018-05-14%2Bat%2B1.50.30%2BPM.jpeg "Lomba mengarang dan membaca puisi dengan tema &quot;bangga jadi polisi")

<small>www.smkn3pbl.sch.id</small>

Puisi tentang wanita. Puisi sahabat macam majalah pendek bait sastra titikdua istilah antologi teks keindahan pemandangan peliharaan ekspresi judul berbentuk gubahan bertema binatang

## 41+ Contoh Puisi Anekdot Pendidikan PNG - Contoh Puisi

![41+ Contoh Puisi Anekdot Pendidikan PNG - Contoh Puisi](https://lh5.googleusercontent.com/proxy/KTCb4kU2d9sS8iY4YASaVW5sG7S7kGLeFX2s29chEiXjrNGCtPsa3KDbAjAScWW_fLYYQteT4tsgB7a6b0Hcw5iW1p9w11c2zaMbLQO-B88FDmfpJ4OJGV49RY9HwP7sT53bBHXUvOMoIvmgbRSP "Pendidikan puisi pendek sekolahku cerpen singkat")

<small>contohpuisiterbaruku.blogspot.com</small>

Contoh puisi bertema hari pendidikan nasional. Puisi kumpulan anyar pendek lingkungan pengarangnya alam pendidikan unsur intrinsiknya kemerdekaan adiwiyata chairil anwar kemanusiaan pantun sunda

## Kumpulan Puisi Tema Pendidikan, Cocok Untuk Referensi Tugas Sekolah

![Kumpulan Puisi Tema Pendidikan, Cocok untuk Referensi Tugas Sekolah](https://assets.pikiran-rakyat.com/crop/0x0:0x0/x/photo/2021/05/02/970654454.jpg "Puisi teks syair pendek geguritan unduh bait cikimm")

<small>portaljember.pikiran-rakyat.com</small>

Puisi syair cikimm. Puisi tema teknologi dan pendidikan

## Contoh Puisi Tema Pendidikan | PUISI INDONESIA

![Contoh Puisi Tema Pendidikan | PUISI INDONESIA](https://1.bp.blogspot.com/-dmtwaHCk0n4/W5P1ZfMKmdI/AAAAAAAAEXo/Tyj-koOxsq4G9N_ITXZkUCS8ujRToL5ygCLcBGAs/s1600/kata.jpg "Pantun nasehat belajar puisi agama bahasa giat sayang lama singkat jenaka aneka macam")

<small>tyassyair.blogspot.com</small>

Kumpulan contoh puisi tentang pendidikan dan sekolah. Lomba mengarang dan membaca puisi dengan tema &quot;bangga jadi polisi

## Lomba Cipta Puisi Nasional Bertema “Pendidikan” Bersama Jejak Publisher

![Lomba Cipta Puisi Nasional Bertema “Pendidikan” Bersama Jejak Publisher](https://jejakpublisher.com/storage/2017/11/Poster-Puisi-Pendidikan.jpg "5 puisi bertema pendidikan")

<small>jejakpublisher.com</small>

Puisi bertema pendidikan nasional. Kumpulan puisi tema pendidikan, cocok untuk referensi tugas sekolah

## Puisi Jawa Pendidikan / Religiusitas Dalam Kumpulan Puisi Jawa Modern

![Puisi Jawa Pendidikan / Religiusitas Dalam Kumpulan Puisi Jawa Modern](https://lh3.googleusercontent.com/proxy/86AJvNKI3UTv7TjYEA7e8J5eq_RxdbGzaHswt6lnTrRHH9sBexe8LZQ1tCb06gSSZXth6iqpYExHN_nl_n9gNuLPvij2QslPgr7rHdCfbTz1DHLGwz4ahOq0XUq3-iP3yi3IMiwcbLvBZLzvCw3l=w1200-h630-p-k-no-nu "Puisi bertema")

<small>daysbelajarsoal.blogspot.com</small>

Baru 27+ puisi pendek tentang sekolah. Kumpulan puisi tema pendidikan, cocok untuk referensi tugas sekolah

## Puisi Tentang Wanita

![Puisi Tentang Wanita](https://image.slidesharecdn.com/kumpulan30puisitentangwanita-130615024424-phpapp01/95/kumpulan-30-puisi-tentang-wanita-32-638.jpg?cb=1371264346 "Pantun nasehat belajar puisi agama bahasa giat sayang lama singkat jenaka aneka macam")

<small>puisiuntukkeluarga.blogspot.com</small>

Puisi pendidikan contoh tentang pantun bermakna lingkungan sekolah beragam pendek singkat dunia cerpen rindu bertemakan kata indah ayah mutiara mengapa. Kumpulan contoh puisi tentang pendidikan dan sekolah

## Contoh Puisi Tentang Lingkungan Hidup 4 Bait ♥ Bergambar ♥

![Contoh Puisi Tentang Lingkungan Hidup 4 Bait ♥ Bergambar ♥](http://4.bp.blogspot.com/-d_wtKx_eiLs/VG7P2mzx7CI/AAAAAAAAAvo/oPd8X21mLa8/s1600/puisi%2Btentang%2Blingkungan%2Bsekolah.jpg "Diriku menginspirasi dunia: puisi hari guru")

<small>puisi-bergambar.blogspot.com.br</small>

Puisi anyar basa warsa duk medal. Lomba mengarang dan membaca puisi dengan tema &quot;bangga jadi polisi

## Contoh Pantun Giat Belajar - Contoh Two

![Contoh Pantun Giat Belajar - Contoh Two](https://imgv2-1-f.scribdassets.com/img/document/15103756/original/678da387a8/1464811782 "Lomba mengarang dan membaca puisi dengan tema &quot;bangga jadi polisi")

<small>contohtwo.blogspot.com</small>

Puisi syair cikimm. Puisi pendidikan pendek singkat bagus banget!

## Puisi Sekolahku Smp

![Puisi Sekolahku Smp](http://pendidikan.kulonprogokab.go.id/files/puisi edis.jpg "Puisi anwar chairil docdroid takut singkat pengarangnya kemanusiaan beserta meuselwitz arbeitsblatt preisbildung riki makna kampus teks cikimm rendra")

<small>kumpulansoal-44.blogspot.com</small>

5 puisi bertema pendidikan. Puisi membaca lomba mengarang probolinggo

## 5 Puisi Bertema Pendidikan | Online Information

![5 puisi bertema pendidikan | Online Information](https://8limbmuaythai.com/wp-content/uploads/2015/11/5-puisi-bertema-pendidikan-630x380.jpg "Puisi sekolahku smp")

<small>8limbmuaythai.com</small>

Puisi pahlawan wanita hardiknas. Kumpulan puisi tema pendidikan, cocok untuk referensi tugas sekolah

## Puisi Pendidikan

![Puisi pendidikan](https://image.slidesharecdn.com/puisipendidikan-130306193856-phpapp02/95/puisi-pendidikan-2-638.jpg?cb=1362598784 "Puisi alam pendidikan keindahan")

<small>www.slideshare.net</small>

√ kumpulan contoh contoh puisi pendidikan. Puisi hevc wpf geguritan telerik

## Contoh Geguritan Tema Pendidikan | KampoengIlmu

![Contoh Geguritan Tema Pendidikan | KampoengIlmu](https://kampoengilmu.com/wp-content/uploads/2016/04/contoh-geguritan-tema-pendidikan.jpg "Lomba mengarang dan membaca puisi dengan tema &quot;bangga jadi polisi")

<small>kampoengilmu.com</small>

Puisi contoh pendidikan lengkap pahlawan. Geguritan puisi bertema teks brainly prosedur majas singkat implications immunosenescence responses accine elicited maaf kalo salah

## Puisi Bali Tema Pendidikan - Kumpulan Puisi Nusantara

![Puisi Bali Tema Pendidikan - Kumpulan Puisi Nusantara](https://image.slidesharecdn.com/kumpulan-puisi-120412013945-phpapp01/95/kumpulan-puisi-17-728.jpg?cb=1334198348 "Puisi bali tema pendidikan")

<small>duniapuisi88.blogspot.com</small>

Puisi pahlawan wanita hardiknas. 33+ contoh puisi pendek tentang lingkungan alam png

## Contoh Puisi Tentang Lingkungan Rumah - Pantun Indonesia

![Contoh Puisi Tentang Lingkungan Rumah - Pantun Indonesia](https://lh5.googleusercontent.com/proxy/Zzn8ivLVmWjQGkHfw2WfcbK0_GBEH8RHy7P1MVkM-nzZ-WJ9VOjjo6bZ62os8kp_tErQJnbiuY0aVV7Pg0LMRO6t-XMDFFyMXkVcOWS76f_y0FSfPhiACJdLmnyFAN5BR8wLKUBhdAosiD0S2bTLNPvLuFMlTWbWP0D1=w1200-h630-p-k-no-nu "Puisi pahlawan wanita hardiknas")

<small>kumpulan-contoh-pantun.blogspot.com</small>

Puisi kemerdekaan pendek singkat kumpulan syair pahlawan persahabatan berantai sahabat lucu romantis agama motivasi kutipan perjuangan tugas simak pengorbanan ustadz. Puisi pendidikan contoh tentang pantun bermakna lingkungan sekolah beragam pendek singkat dunia cerpen rindu bertemakan kata indah ayah mutiara mengapa

## Puisi Tema Teknologi Dan Pendidikan

![Puisi Tema Teknologi Dan Pendidikan](https://imgv2-1-f.scribdassets.com/img/document/132897219/original/f88bd83bf8/1562441142?v=1 "Puisi pendidikan pendek singkat bagus banget!")

<small>www.scribd.com</small>

Puisi pendidikan. Puisi kemerdekaan pendek singkat kumpulan syair pahlawan persahabatan berantai sahabat lucu romantis agama motivasi kutipan perjuangan tugas simak pengorbanan ustadz

## 37+ Contoh Puisi Pendek, Lama, Baru, Ibu, Guru, Persahabatan, Cinta

![37+ Contoh Puisi Pendek, lama, Baru, Ibu, Guru, Persahabatan, Cinta](https://contoh.pro/wp-content/uploads/2018/06/Contoh-puisi-kemerdekaan-indonesia-1945.jpg "33+ contoh puisi pendek tentang lingkungan alam png")

<small>contoh.pro</small>

Puisi membaca lomba mengarang probolinggo. Contoh puisi bertema hari pendidikan nasional

## 32+ Contoh Contoh Puisi Tema Pendidikan

![32+ Contoh Contoh Puisi Tema Pendidikan](https://lh3.googleusercontent.com/proxy/fRbqH6PbOOrfQWvfI1VVC0UCFAxI80ypbRfJMR5bQeqXXTjAvLhn1gJjCLECJYJDBVuu-WJPVPj7pR5mq5nXOVaUw8m0k9kSxfss5Z2CAb_pihzUXo_ldVfsSGSBwE2Tl5xXu6012Qt7QrnpECWn=w1200-h630-p-k-no-nu "Puisi pendidikan")

<small>1001pantundanpuisi.blogspot.com</small>

Contoh puisi pendek tentang pendidikan. Puisi hevc wpf geguritan telerik

## Kumpulan Contoh Puisi Tentang Pendidikan Dan Sekolah | PUISI INDONESIA

![Kumpulan Contoh Puisi Tentang Pendidikan Dan Sekolah | PUISI INDONESIA](https://3.bp.blogspot.com/-qP1zBQQcbOc/Wt3UO7udA7I/AAAAAAAADkQ/VuKVVBLSVrkn-ZdjHh3TTBn1wXuEJNuWwCLcBGAs/s1600/pahlawan.jpg "Puisi teks syair pendek geguritan unduh bait cikimm")

<small>tyassyairbaru.blogspot.com</small>

41+ contoh puisi anekdot pendidikan png. Baru 27+ puisi pendek tentang sekolah

## Puisi Pendidikan

![Puisi pendidikan](https://cdn.slidesharecdn.com/ss_thumbnails/puisipendidikan-130306193856-phpapp02-thumbnail-4.jpg?cb=1362598784 "Puisi kemerdekaan pendek singkat kumpulan syair pahlawan persahabatan berantai sahabat lucu romantis agama motivasi kutipan perjuangan tugas simak pengorbanan ustadz")

<small>www.slideshare.net</small>

Lomba cipta puisi nasional bertema “pendidikan” bersama jejak publisher. Puisi pendidikan pendek singkat bagus banget!

## Puisi Bertema Pendidikan Nasional - Kumpulan Puisi

![Puisi Bertema Pendidikan Nasional - Kumpulan Puisi](https://imgv2-2-f.scribdassets.com/img/document/104193274/original/6ad93b93f3/1559269714?v=1 "Puisi pahlawan wanita hardiknas")

<small>puisisutra.blogspot.com</small>

Puisi contoh pendidikan lengkap pahlawan. Geguritan tema pendidikan singkat

## √ Kumpulan Contoh Contoh Puisi Pendidikan - Contoh Kumpulan Puisi Baru

![√ Kumpulan Contoh Contoh Puisi Pendidikan - Contoh Kumpulan Puisi Baru](http://daftarkumpulanterbaru.com/wp-content/uploads/2014/03/Puisi-Indah-Di-Bidang-Pendidikan.jpg "Puisi bertema")

<small>puisibarubaik.blogspot.com</small>

Puisi pendidikan lomba cipta bertema jejak anak antariksa contoh pantun assalamu alaikum jejakpublisher. Puisi bali tema pendidikan

## Contoh Puisi Bertema Hari Pendidikan Nasional - Terkait Pendidikan

![Contoh Puisi Bertema Hari Pendidikan Nasional - Terkait Pendidikan](https://2.bp.blogspot.com/-B_rki_SjbrY/Ve_UWLPB3lI/AAAAAAAAAOo/XVH_oxNFPAI/w1200-h630-p-k-no-nu/Puisi%2BHARDIKNAS%2B1.jpg "Puisi sekolahku smp")

<small>terkaitpendidikan.blogspot.com</small>

Puisi sekolahku smp. Puisi tema teknologi dan pendidikan

## 10+ Ide Puisi Tentang Lingkungan Sekolah 2 Bait - Juustement

![10+ Ide Puisi Tentang Lingkungan Sekolah 2 Bait - Juustement](https://titikdua.net/wp-content/uploads/2019/02/Contoh-Puisi-Anak-SD.jpg "37+ contoh puisi pendek, lama, baru, ibu, guru, persahabatan, cinta")

<small>juustement.blogspot.com</small>

Puisi pantun. 47+ contoh puisi tentang pendidikan karakter images

## 33+ Contoh Puisi Pendek Tentang Lingkungan Alam PNG - Contoh Puisi

![33+ Contoh Puisi Pendek Tentang Lingkungan Alam PNG - Contoh Puisi](https://lh6.googleusercontent.com/proxy/dum9N1KsBhe4KyLIwsZYaLKlokeKDtVLeZHH0lzv9KS87QBfxkJP0_RwBwZ_xPRiIOZ6--vJ1492OYeuv2iAcfiTkQGN7GIuotffU3OUyntgduu7zrBpK5fIM43FJKE-XjcQn69w-SaC22gXcQ3vWmiJIB_bQKKfg7u7cV387i2bAguV7fHnVvdDg8_A4egV7IvQN15p "Puisi anwar chairil docdroid takut singkat pengarangnya kemanusiaan beserta meuselwitz arbeitsblatt preisbildung riki makna kampus teks cikimm rendra")

<small>contohpuisiterbaruku.blogspot.com</small>

Puisi pendidikan contoh tentang pantun bermakna lingkungan sekolah beragam pendek singkat dunia cerpen rindu bertemakan kata indah ayah mutiara mengapa. Mutiara motivasi puisi ucapan pensiun perpisahan kutipan bbm bijak singkat murid persaraan quotemutiara naskah nasional seniman bermutu siswa hikmah maafkan

## Contoh Puisi Pendek Tentang Pendidikan - Pantun Indonesia

![Contoh Puisi Pendek Tentang Pendidikan - Pantun Indonesia](https://2.bp.blogspot.com/-NUz2Nz9CxeQ/W_7CPmnPrhI/AAAAAAAAHI8/PaykykAmfhcwqAjdTXly2tIiewjPUPCNwCLcBGAs/w1200-h630-p-k-no-nu/Kumpulan%2BPuisi%2BPendek%2Bbertema%2BPendidikan.png "33+ contoh puisi pendek tentang lingkungan alam png")

<small>kumpulan-contoh-pantun.blogspot.com</small>

Contoh puisi bertema hari pendidikan nasional. Puisi pendidikan bertema

## 10 Contoh Puisi Tentang Pendidikan | Online Information

![10 contoh puisi tentang pendidikan | Online Information](https://8limbmuaythai.com/wp-content/uploads/2015/11/10-contoh-puisi-tentang-pendidikan.png "37+ contoh puisi pendek, lama, baru, ibu, guru, persahabatan, cinta")

<small>8limbmuaythai.com</small>

Kumpulan contoh puisi tentang pendidikan dan sekolah. Puisi pendidikan contoh tentang pantun bermakna lingkungan sekolah beragam pendek singkat dunia cerpen rindu bertemakan kata indah ayah mutiara mengapa

## Puisi Pendidikan Pendek Singkat Bagus Banget! - Education

![Puisi Pendidikan Pendek Singkat Bagus Banget! - Education](https://1.bp.blogspot.com/-8IO-EJ4QcQs/X7MBzv82TwI/AAAAAAAAEPk/NxU2fHM7uREo64VGjjX4BNQIQ2vP8k4UgCLcBGAsYHQ/s2048/puisi-pendidikan-singkat%2B%25284%2529.jpg "Contoh puisi bertema hari pendidikan nasional")

<small>seuntaipuisi.blogspot.com</small>

Puisi hevc wpf geguritan telerik. Puisi bertema pendidikan nasional

## Geguritan Tema Pendidikan Singkat - Berkas Sekolah

![Geguritan Tema Pendidikan Singkat - Berkas Sekolah](https://lh6.googleusercontent.com/proxy/vU_zhxO4MUXAmDLgrFCxKXB0sXTCMBULfh5VijrbC0g6laZD265RIJwp9i0knLtISWhW6w5YHXMg-dYRj5AymyU6gsd61BJ8pkIsmHMz9wnlZzL1CMugddT9owTN=w1200-h630-p-k-no-nu "Pantun nasehat belajar puisi agama bahasa giat sayang lama singkat jenaka aneka macam")

<small>berkassekolahguru.blogspot.com</small>

Diriku menginspirasi dunia: puisi hari guru. Puisi anwar chairil docdroid takut singkat pengarangnya kemanusiaan beserta meuselwitz arbeitsblatt preisbildung riki makna kampus teks cikimm rendra

## 47+ Contoh Puisi Tentang Pendidikan Karakter Images - Hutomo

![47+ Contoh Puisi Tentang Pendidikan Karakter Images - Hutomo](https://i1.wp.com/0.academia-photos.com/attachment_thumbnails/51329504/mini_magick20180819-28321-rif5sf.png?resize=612%2C792&amp;ssl=1 "Geguritan tema pendidikan singkat")

<small>id.hutomosungkar.com</small>

Syarat laboratorium teknologi. Puisi bertema pendidikan nasional

Puisi chairil karya anwar bertema. Pantun nasehat belajar puisi agama bahasa giat sayang lama singkat jenaka aneka macam. Contoh puisi tentang lingkungan rumah
