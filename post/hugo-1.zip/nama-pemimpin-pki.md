---
title: "nama pemimpin pki"
description: "Pahlawan patung revolusi g30s pki monumen gugur g30spki fungsi bersejarah boombastis buaya lubang gerakan kasih bangga pancasila tokoh alat ketujuh"
date: "2022-03-01"
categories:
- "bumi"
images:
- "https://i1.wp.com/thegorbalsla.com/wp-content/uploads/2018/10/Pahlawan-Revolusi.jpg?fit=1187%2C650&amp;ssl=1"
featuredImage: "https://assets.pikiran-rakyat.com/crop/0x0:0x0/750x500/photo/2022/09/12/2076606883.png"
featured_image: "https://1.bp.blogspot.com/-6WA1kNUeG0E/XXYrr2U-UZI/AAAAAAAABiM/a-gZXRWuA3MJboE-adxu39pdyj_GIfZMwCLcBGAs/w1200-h630-p-k-no-nu/pahlawan%2BRevolusi.jpg"
image: "http://4.bp.blogspot.com/-by49sdHCbvE/U5xPcuqio-I/AAAAAAAAFqc/HOby6cnrpXI/s1600/pahlawan+revolusi+2.jpg"
---

If you are searching about 10 Nama Pahlawan Revolusi Yang Gugur Saat Tragedi G30S | namapedia you've came to the right place. We have 35 Images about 10 Nama Pahlawan Revolusi Yang Gugur Saat Tragedi G30S | namapedia like Biodata DN Aidit, Lengkap Umur dan Agama, Pemimpin PKI yang Fenomenal, 10 Pahlawan Revolusi Indonesia | Nama, Biografi, Gambar (Lengkap) and also Museum Lubang Buaya Mengenang Pahlawan Revolusi. Here you go:

## 10 Nama Pahlawan Revolusi Yang Gugur Saat Tragedi G30S | Namapedia

![10 Nama Pahlawan Revolusi Yang Gugur Saat Tragedi G30S | namapedia](http://4.bp.blogspot.com/-Xc0_TuWn2is/UwiU52w-40I/AAAAAAAAAF4/cy6TbixazPQ/s1600/patung+pahlawan+revolusi.jpg "Bangsa anri pemimpin nawanawa g30s pemberontakan pki 1965 suharman")

<small>namapedia.blogspot.com</small>

Wisata sejarah ke monumen kresek di madiun, tempat napak tilas. Pki g30s korban g30spki perwira pemberontakan tokoh jenderal gerakan sebutkan pahlawan peristiwa pembunuhan gugur fakta jendral tujuh andi tura katamso

## Pemberontakan PKI Madiun Tahun 1948 | Freedomsiana

![Pemberontakan PKI Madiun Tahun 1948 | Freedomsiana](https://2.bp.blogspot.com/-m7k6oJdNvN0/WCBbCSSDHvI/AAAAAAAACiE/ihNMjLTZXvI3sUQvKUp0NWjyGvRwt7RTwCLcB/s1600/PKI%2BMadiun.png "Biodata dn aidit, lengkap umur dan agama, pemimpin pki yang fenomenal")

<small>www.freedomsiana.id</small>

Ringkasan sejarah pemberontakan g30s pki beserta 10 nama pahlawan. Pki g30s tritura jalan gerakan demonstrasi mengadakan menyerukan peristiwa kronologi catatan

## G 30 S PKI | Nama-nama Jendral Yang Menjadi Korban PKI - YouTube

![G 30 S PKI | Nama-nama Jendral yang menjadi korban PKI - YouTube](https://i.ytimg.com/vi/WaAdSfnulyI/hqdefault.jpg "Pki musso madiun muso pemberontakan pemimpin suripno bangkit vitae")

<small>www.youtube.com</small>

Kisah dn aidit, dikenal pemimpin terakhir pki yang antagonis,ternyata. Sebutkan nama-nama perwira korban g30s/pki! sebutkan isi tri tura

## Pemimpin G30s Pki Jakarta - 31 Ogos 2018

![Pemimpin G30s Pki Jakarta - 31 Ogos 2018](https://lh5.googleusercontent.com/proxy/bsf8S6ymrkKwTyabb80mqvky9xXUJSSPhBGFHRlCZive2M5n0J10yxnufbDlFbgZYK4ubuSGW-Q2RJnLM88wwpUN_IkiLUSSGQZlsvyQjp0d4IKTXCYS26y3IKzDwNdRZJyKJM4_owDQCM8AY3yS3zS3o05VEtF0ryufHPJOa57o6THkzLlb_mfAc6Q=w1200-h630-p-k-no-nu "Pahlawan revolusi pki g30s peristiwa jendral nama gerakan tokoh gugur dibunuh pemuda sosok penculikan madiun perwira puisi siapakah g30spki jenderal")

<small>31ogos2018.blogspot.com</small>

Pemberontakan pki madiun tahun 1948. Partai komunis indonesia (awal kemunculan hingga kehancuran)

## Museum Lubang Buaya Mengenang Pahlawan Revolusi

![Museum Lubang Buaya Mengenang Pahlawan Revolusi](https://2.bp.blogspot.com/-qmw7VyqaGAw/U1ZjaBoiNDI/AAAAAAAAA5U/3l8FVYYJGaM/s1600/Untitled-8.jpg "Musso (pemimpin pemberontakan pki madiun)")

<small>budayaindonesiasatu.blogspot.com</small>

Musso pemberontakan pki muso madiun komunis tokoh pemimpin penumpasan kembalinya hidupnya perjalanan ardiwinata daeng biografi edisi khusus. Sosialisme di indonesia: dari sneevliet hingga soekarno, dari pemimpin

## Kisah Hidup Letkol Untung, Tokoh Sentral Tragedi G30S/PKI - Kumparan.com

![Kisah Hidup Letkol Untung, Tokoh Sentral Tragedi G30S/PKI - kumparan.com](https://blue.kumparan.com/image/upload/fl_progressive,fl_lossy,c_fill,q_auto:best,w_640/v1601456900/sudjmqi4b2n5datwqhmh.jpg "Aidit pki pemimpin biodata umur fenomenal inilah terserak puisi sekumpulan dulu dirinya diganti achmad")

<small>kumparan.com</small>

Aidit pki pemimpin biodata umur fenomenal inilah terserak puisi sekumpulan dulu dirinya diganti achmad. Ringkasan sejarah pemberontakan g30s pki beserta 10 nama pahlawan

## MUSSO (Pemimpin Pemberontakan PKI Madiun) | Kejahatan Dan Kemuliaan

![MUSSO (Pemimpin Pemberontakan PKI Madiun) | Kejahatan dan Kemuliaan](http://4.bp.blogspot.com/-Mb8YAUeWUeg/UK9AYEWHvwI/AAAAAAAAATM/oUvd8_X6C9A/s1600/musso.jpg "Biodata dn aidit, lengkap umur dan agama, pemimpin pki yang fenomenal")

<small>kataitucinta.blogspot.com</small>

Kumpulan kata-kata mutiara peringatan peristiwa g30s pki, ucapan bijak. 10 nama pahlawan revolusi yang gugur saat tragedi g30s

## Sebutkan Nama-Nama Perwira Korban G30S/PKI! Sebutkan Isi Tri Tura

![Sebutkan Nama-Nama Perwira Korban G30S/PKI! Sebutkan Isi Tri Tura](https://1.bp.blogspot.com/-frc7bordFxY/VvVREPEwi8I/AAAAAAAAAjg/yhQBN6MLUX8E0Bbu0U1AZsBhbXKgFFZLA/s1600/Korban%2BG30S%2BPKI.jpg "Musso (pemimpin pemberontakan pki madiun)")

<small>pendidikanzone.blogspot.com</small>

Musso (pemimpin pemberontakan pki madiun). G30s korban pki

## Mengenang Peristiwa G30S/PKI Di Monumen Pahlawan Pancasila

![Mengenang Peristiwa G30S/PKI di Monumen Pahlawan Pancasila](https://www.wisatasleman.com/wp-content/uploads/2021/05/44456678_280091952628646_4448099394497053628_n.jpg "Pemimpin pki sosialisme soekarno menuju sneevliet prinsip internasional permasalahan")

<small>www.wisatasleman.com</small>

Sejarah lengkap kronologi peristiwa gerakan 30 september 1965 (g30s/pki. Sebutkan nama-nama perwira korban g30s/pki! sebutkan isi tri tura

## Pemimpin Pemberontakan G30s Pki 1965 - Spooky I

![Pemimpin Pemberontakan G30s Pki 1965 - Spooky i](https://2.bp.blogspot.com/-ziwX1fXh_m8/UlpJCZFmRTI/AAAAAAAAA9w/uTNviXuNB6k/s1600/DSC00596+-+Copy.JPG "Musso pki muso madiun pemberontakan kebijakan komunis partai akhir hayat skak donisetyawan pasukan belanda paseban bocah alim melawan lupa udinese")

<small>spookyi.blogspot.com</small>

10 nama pahlawan revolusi yang gugur saat tragedi g30s. Inilah 5 kisah tragis akhir hidup tokoh pki

## WikanDatu

![wikanDatu](https://4.bp.blogspot.com/-9QjfRpU9jeM/UQln0qTG0lI/AAAAAAAAA6c/uSX-8_j_R4s/s200/Mh_lukman.jpg "Pki musso madiun muso pemberontakan pemimpin suripno bangkit vitae")

<small>wikandatu.blogspot.com</small>

Lubang buaya mengenang revolusi pahlawan budaya pki g30s terletak pondok kawasan sejarah museums. G30s pki peristiwa monumen pahlawan pancasila

## Sosialisme Di Indonesia: Dari Sneevliet Hingga Soekarno, Dari Pemimpin

![Sosialisme di Indonesia: Dari Sneevliet Hingga Soekarno, Dari Pemimpin](https://i0.wp.com/www.arahjuang.com/wp-content/uploads/2014/02/PKI-1.jpg "Sosok letkol untung syamsuri, tokoh penting di balik g30s/pki, benarkah")

<small>www.arahjuang.com</small>

Inilah 5 kisah tragis akhir hidup tokoh pki. Ringkasan sejarah pemberontakan g30s pki beserta 10 nama pahlawan

## KUMPULAN Kata-Kata Mutiara Peringatan Peristiwa G30S PKI, Ucapan Bijak

![KUMPULAN Kata-Kata Mutiara Peringatan Peristiwa G30S PKI, Ucapan Bijak](https://cdn-2.tstatic.net/manado/foto/bank/images/potret-para-jenderal-dan-perwira-yang-dibunuh-dalam-g30s-pki.jpg "Daeng muhammad ardiwinata: penumpasan pemberontak pki madiun")

<small>manado.tribunnews.com</small>

Daily of random kids: gerakan 30 september (g30s pki). Pahlawan revolusi korban katamso pki g30s peristiwa brigadir jenderal

## Inilah 5 Kisah Tragis Akhir Hidup Tokoh PKI | Pegawai Jalanan ~ PEGAWAI

![Inilah 5 Kisah Tragis Akhir Hidup Tokoh PKI | Pegawai Jalanan ~ PEGAWAI](https://1.bp.blogspot.com/-J0PWe2jNzFM/Xg6apqx7dHI/AAAAAAAACsU/jtFFh4Bpuxce-S1iBPB57rYLlP-W28pNwCEwYBhgL/s1600/mh-lukman.jpg "Biodata dn aidit, lengkap umur dan agama, pemimpin pki yang fenomenal")

<small>www.pegawaijalanan.com</small>

G 30 s pki. Pemberontakan pki madiun tahun 1948

## Daily Of Random Kids: Gerakan 30 September (G30S PKI)

![Daily Of Random Kids: Gerakan 30 September (G30S PKI)](http://4.bp.blogspot.com/-by49sdHCbvE/U5xPcuqio-I/AAAAAAAAFqc/HOby6cnrpXI/s1600/pahlawan+revolusi+2.jpg "Pki g30s jenderal potret tokoh perwira pengkhianatan pahlawan g30spki ucapan peringatan dibunuh bijak peristiwa revolusi mutiara mahfud larang")

<small>arsyiarsyo.blogspot.com</small>

Pahlawan patung revolusi g30s pki monumen gugur g30spki fungsi bersejarah boombastis buaya lubang gerakan kasih bangga pancasila tokoh alat ketujuh. Daeng muhammad ardiwinata: penumpasan pemberontak pki madiun

## Biodata DN Aidit, Lengkap Umur Dan Agama, Pemimpin PKI Yang Fenomenal

![Biodata DN Aidit, Lengkap Umur dan Agama, Pemimpin PKI yang Fenomenal](https://kuyou.id/content/images/4-20200916122838.jpg "G30s korban pki")

<small>kuyou.id</small>

Musso pki muso madiun pemberontakan kebijakan komunis partai akhir hayat skak donisetyawan pasukan belanda paseban bocah alim melawan lupa udinese. Daeng muhammad ardiwinata: penumpasan pemberontak pki madiun

## Wisata Sejarah Ke Monumen Kresek Di Madiun, Tempat Napak Tilas

![Wisata Sejarah ke Monumen Kresek di Madiun, Tempat Napak Tilas](https://asset.kompas.com/crops/b7iuozSK7KMuCFFrx20EfYoAlIk=/195x5:1155x645/750x500/data/photo/2019/10/02/5d93f4b252228.jpg "Bangsa anri pemimpin nawanawa g30s pemberontakan pki 1965 suharman")

<small>travel.tribunnews.com</small>

Komik &amp; komputer informasi: nama 10 pahlawan revolusi korban peristiwa. Kisah hidup letkol untung, tokoh sentral tragedi g30s/pki

## Inilah 5 Kisah Tragis Akhir Hidup Tokoh PKI | Pegawai Jalanan ~ PEGAWAI

![Inilah 5 Kisah Tragis Akhir Hidup Tokoh PKI | Pegawai Jalanan ~ PEGAWAI](https://1.bp.blogspot.com/-N-pWFP4mzf0/Xg6apg1GS2I/AAAAAAAACsU/YwcVblBqxigV9wpdc8pWzUCkBnmr2KWlQCEwYBhgL/s640/dipa-nusantara-aidit.jpg "Pki g30s korban g30spki perwira pemberontakan tokoh jenderal gerakan sebutkan pahlawan peristiwa pembunuhan gugur fakta jendral tujuh andi tura katamso")

<small>www.pegawaijalanan.com</small>

Biodata dn aidit, lengkap umur dan agama, pemimpin pki yang fenomenal. Lukman hatta muhammad

## Biodata DN Aidit, Lengkap Umur Dan Agama, Pemimpin PKI Yang Fenomenal

![Biodata DN Aidit, Lengkap Umur dan Agama, Pemimpin PKI yang Fenomenal](https://kuyou.id/content/images/1-20200916122915.jpg "Partai komunis indonesia (awal kemunculan hingga kehancuran)")

<small>kuyou.id</small>

10 nama pahlawan revolusi yang gugur saat tragedi g30s. Lukman hatta

## Sejarah Lengkap Kronologi Peristiwa Gerakan 30 September 1965 (G30S/PKI

![Sejarah Lengkap Kronologi Peristiwa Gerakan 30 September 1965 (G30S/PKI](https://2.bp.blogspot.com/-oflecEV7TaM/WHWnXnS2VLI/AAAAAAAACI0/QRzjGNQDDOcG2NWbCOvfq15iLii4bFzMACEw/s1600/pki6.JPG "Biodata dn aidit, lengkap umur dan agama, pemimpin pki yang fenomenal")

<small>catatansejarahrepublikindonesia.blogspot.com</small>

Kumpulan kata-kata mutiara peringatan peristiwa g30s pki, ucapan bijak. Pki musso madiun muso pemberontakan pemimpin suripno bangkit vitae

## 10 Pahlawan Revolusi Indonesia | Nama, Biografi, Gambar (Lengkap)

![10 Pahlawan Revolusi Indonesia | Nama, Biografi, Gambar (Lengkap)](https://i1.wp.com/thegorbalsla.com/wp-content/uploads/2018/10/Pahlawan-Revolusi.jpg?fit=1187%2C650&amp;ssl=1 "Musso pki muso madiun pemberontakan kebijakan komunis partai akhir hayat skak donisetyawan pasukan belanda paseban bocah alim melawan lupa udinese")

<small>thegorbalsla.com</small>

Pki tjakrabirawa g30s asal pusaran usul. Ringkasan sejarah pemberontakan g30s pki beserta 10 nama pahlawan

## KISAH DN Aidit, Dikenal Pemimpin Terakhir PKI Yang Antagonis,Ternyata

![KISAH DN Aidit, Dikenal Pemimpin Terakhir PKI yang Antagonis,Ternyata](https://cdn-2.tstatic.net/cirebon/foto/bank/images/KISAH-DN-Aidit-Dikenal-Pemimpin-Terakhir-PKI-yang-AntogisTernyata-Rajin-Ibadah-Mengaji.jpg "Daeng muhammad ardiwinata: penumpasan pemberontak pki madiun")

<small>cirebon.tribunnews.com</small>

Komik &amp; komputer informasi: nama 10 pahlawan revolusi korban peristiwa. Alasan gembong pki ubah nama dari achmad menjadi dn aidit, ayah tak

## Kebijakan Jalan Baru Musso – Donisaurus

![Kebijakan Jalan Baru Musso – Donisaurus](http://www.donisetyawan.com/wp-content/uploads/2016/10/musso.png "Inilah 5 kisah tragis akhir hidup tokoh pki")

<small>www.donisetyawan.com</small>

Kebijakan jalan baru musso – donisaurus. Biodata dn aidit, lengkap umur dan agama, pemimpin pki yang fenomenal

## Biodata DN Aidit, Lengkap Umur Dan Agama, Pemimpin PKI Yang Fenomenal

![Biodata DN Aidit, Lengkap Umur dan Agama, Pemimpin PKI yang Fenomenal](https://kuyou.id/content/images/mantap-20200916123323.jpg "Biodata dn aidit, lengkap umur dan agama, pemimpin pki yang fenomenal")

<small>kuyou.id</small>

Pki tjakrabirawa g30s asal pusaran usul. Pki g30s jenderal potret tokoh perwira pengkhianatan pahlawan g30spki ucapan peringatan dibunuh bijak peristiwa revolusi mutiara mahfud larang

## Sosok Letkol Untung Syamsuri, Tokoh Penting Di Balik G30S/PKI, Benarkah

![Sosok Letkol Untung Syamsuri, Tokoh Penting di Balik G30S/PKI, Benarkah](https://cdn-2.tstatic.net/jambi/foto/bank/images/21092020_soekarno2.jpg "Nama pemimpin g30s pki")

<small>updatenews24jam.blogspot.com</small>

Musso pki muso madiun pemberontakan kebijakan komunis partai akhir hayat skak donisetyawan pasukan belanda paseban bocah alim melawan lupa udinese. Sejarah lengkap kronologi peristiwa gerakan 30 september 1965 (g30s/pki

## Ringkasan Sejarah Pemberontakan G30S PKI Beserta 10 Nama Pahlawan

![Ringkasan Sejarah Pemberontakan G30S PKI beserta 10 Nama Pahlawan](https://assets.pikiran-rakyat.com/crop/0x0:0x0/750x500/photo/2021/09/30/1517207913.jpg "G30s pki peristiwa monumen pahlawan pancasila")

<small>zonabanten.pikiran-rakyat.com</small>

10 nama pahlawan revolusi yang gugur saat tragedi g30s. G 30 s pki

## KOMIK &amp; KOMPUTER INFORMASI: Nama 10 Pahlawan Revolusi Korban Peristiwa

![KOMIK &amp; KOMPUTER INFORMASI: Nama 10 Pahlawan Revolusi Korban Peristiwa](https://1.bp.blogspot.com/-6WA1kNUeG0E/XXYrr2U-UZI/AAAAAAAABiM/a-gZXRWuA3MJboE-adxu39pdyj_GIfZMwCLcBGAs/w1200-h630-p-k-no-nu/pahlawan%2BRevolusi.jpg "Kisah sebenarnya, kenapa pki bunuh 6 jenderal &amp; 1 perwira 30 september")

<small>kokominfo.blogspot.com</small>

Pki tjakrabirawa g30s asal pusaran usul. 10 nama pahlawan revolusi yang gugur saat tragedi g30s

## Nama Pemimpin G30s Pki - Kris Greet

![Nama Pemimpin G30s Pki - Kris Greet](https://image.slidesharecdn.com/pki-131109093258-phpapp01/95/pki-partai-komunis-indonesia-7-638.jpg?cb=1383989604 "Wisata sejarah ke monumen kresek di madiun, tempat napak tilas")

<small>krisgreet.blogspot.com</small>

Musso (pemimpin pemberontakan pki madiun). Aidit pki pemimpin biodata fenomenal agama umur istimewa

## Partai Komunis Indonesia (awal Kemunculan Hingga Kehancuran) - Sejarah

![Partai Komunis Indonesia (awal kemunculan hingga kehancuran) - Sejarah](http://1.bp.blogspot.com/-tciaimtdk8M/VguZST1MXSI/AAAAAAAAAOQ/T02304IyyXo/s1600/henk-sneevliet-duduk-di-tengah-bersama-anggota-isdv-semarang.jpg "Tokoh pemberontakan pki madiun [nama dan sejarahnya] lengkap")

<small>peradabandansejarah.blogspot.co.id</small>

Musso pki muso madiun pemberontakan kebijakan komunis partai akhir hayat skak donisetyawan pasukan belanda paseban bocah alim melawan lupa udinese. Musso pemberontakan pki muso madiun komunis tokoh pemimpin penumpasan kembalinya hidupnya perjalanan ardiwinata daeng biografi edisi khusus

## Kisah Sebenarnya, Kenapa PKI Bunuh 6 Jenderal &amp; 1 Perwira 30 September

![Kisah Sebenarnya, Kenapa PKI Bunuh 6 Jenderal &amp; 1 Perwira 30 September](https://cdn-2.tstatic.net/manado/foto/bank/images/kesaksian-personel-kko-al-12121.jpg "Sebutkan nama-nama perwira korban g30s/pki! sebutkan isi tri tura")

<small>manado.tribunnews.com</small>

G 30 s pki. Komunis partai isdv sejarah sneevliet henk pki buruh organisasi mula belanda mengenal pembawa ajaran radikal pemberontakan komunisme peradaban idsejarah awal

## Tokoh Pemberontakan PKI Madiun [Nama Dan Sejarahnya] Lengkap - Fakta

![Tokoh Pemberontakan PKI Madiun [Nama dan Sejarahnya] Lengkap - Fakta](https://4.bp.blogspot.com/-UYA_C2MA6ws/WwLygjatoqI/AAAAAAAAJtA/r5crM9KpE2Yu1jFn5L5YupcU0rtqwSJ8ACLcBGAs/s1600/Pemberontakan%2BPKI%2BMadiun.png "G30s pki peristiwa monumen pahlawan pancasila")

<small>www.faktatokoh.com</small>

Partai komunis indonesia (awal kemunculan hingga kehancuran). G 30 s pki

## Alasan Gembong PKI Ubah Nama Dari Achmad Menjadi DN Aidit, Ayah Tak

![Alasan Gembong PKI Ubah Nama dari Achmad Menjadi DN Aidit, Ayah Tak](https://assets.pikiran-rakyat.com/crop/0x0:0x0/750x500/photo/2022/09/12/2076606883.png "Wisata sejarah ke monumen kresek di madiun, tempat napak tilas")

<small>minahasa.pikiran-rakyat.com</small>

Sebutkan nama-nama perwira korban g30s/pki! sebutkan isi tri tura. Partai komunis indonesia (awal kemunculan hingga kehancuran)

## Nama Korban G30s Pki Lubang Buaya - Ketisyur

![Nama Korban G30s Pki Lubang Buaya - Ketisyur](https://lh6.googleusercontent.com/proxy/uWD8jrt9yDZmrSVJ3zuntiiBOI3b_QH0xui6a5l86dHqlVQ67nTvbpug6_DcxqMfTwUT-ucxMFmefmJliOn4jyvf4CN-V-kl3wdciXFOGtg=w1200-h630-p-k-no-nu "G30s pki peristiwa monumen pahlawan pancasila")

<small>ketisyur.blogspot.com</small>

Kisah dn aidit, dikenal pemimpin terakhir pki yang antagonis,ternyata. Pki musso madiun muso pemberontakan pemimpin suripno bangkit vitae

## Daeng Muhammad Ardiwinata: Penumpasan Pemberontak PKI Madiun

![Daeng Muhammad Ardiwinata: Penumpasan Pemberontak PKI Madiun](http://1.bp.blogspot.com/-exoPXMQa0sA/UdQyM1qkwiI/AAAAAAAAEwg/7PsZ0SSFZPE/s361/1.jpg "Musso pemberontakan pki muso madiun komunis tokoh pemimpin penumpasan kembalinya hidupnya perjalanan ardiwinata daeng biografi edisi khusus")

<small>dickyrachmadie.blogspot.com</small>

Pki madiun pemberontakan tokoh komunis indonesia keras hatta kebijakan mengecam diberi muso kabinet. Aidit pki pemimpin biodata fenomenal agama umur istimewa

## Asal-Usul Nama Tjakrabirawa Di Pusaran G30S/PKI | KASKUS

![Asal-Usul Nama Tjakrabirawa di Pusaran G30S/PKI | KASKUS](https://s.kaskus.id/images/2017/09/30/9893777_20170930072117.jpg "Asal-usul nama tjakrabirawa di pusaran g30s/pki")

<small>www.kaskus.co.id</small>

Musso pki muso madiun pemberontakan kebijakan komunis partai akhir hayat skak donisetyawan pasukan belanda paseban bocah alim melawan lupa udinese. Lukman hatta muhammad

Sejarah lengkap kronologi peristiwa gerakan 30 september 1965 (g30s/pki. Partai komunis indonesia (awal kemunculan hingga kehancuran). Asal-usul nama tjakrabirawa di pusaran g30s/pki
