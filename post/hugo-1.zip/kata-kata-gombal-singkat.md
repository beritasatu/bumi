---
title: "kata kata gombal singkat"
description: "25 kata kata gombal buat pacar yang bisa dijadikan inspirasi"
date: "2022-01-24"
categories:
- "bumi"
images:
- "https://1.bp.blogspot.com/-Cf7bZYpK6J4/VWE83WSae3I/AAAAAAAAC4E/of1Jj5pJDWQ/s1600/kata25252Bkata25252Blucu-tahpedia.jpg"
featuredImage: "https://lh5.googleusercontent.com/proxy/TjtmZpRhWoovCDPk8mvj4kTGExjiPwNyiwF1b5oDlARaD4jhhJrtF8rpwxIlu3luyT-nSK_a-fqpIqwG81HFnzzC8rlhh938gLR2LpqQewDVUFIYCWawPXeSIMw427V59UxJ8lPnXG-x21DcUebhyLqI0Wk7MCsWsK7gOg49hWLvETTX8LMXMZ46BqYygPGXtP-HQrgepliAqJOKzdNXcj8Qps785LQEEjbDYreiM_vbuZpv3TqHl9k6frNXdtYHZujcMHFOh-Y24D8vkWK2Ixet4dNFOSrw7P3XgQ8OgKJQQeLyhIunvzYB9ffKck5ML6MI8TI3=w1200-h630-p-k-no-nu"
featured_image: "https://lh5.googleusercontent.com/proxy/GkFFoR1SEPGImFm-zlECemCvr77mXUaRPyVcaZ4ewQNp03wSmCUIYgmRhomfuL1rsKor-2xxJo8oolVqlf-s5suWMe0XgZArQ5gIJEVYX_mNPwyoNdUjGEQjoFUge6lCC32t2gDx3ZRpo9c2TMR5_OD5iyGG3N5qgbkgV1llSOxVWnwVWNah8VaVHZUxM6WyxB5sabzdowsTwORK1_8A2w=w1200-h630-p-k-no-nu"
image: "https://cdn.en.wtf/wp-content/uploads/2018/06/gambar-motivasi-hidup-sukses.jpg"
---

If you are searching about Pantun Gombalan Romantis - Kumpulan Kata Motivasi you've came to the right place. We have 35 Pics about Pantun Gombalan Romantis - Kumpulan Kata Motivasi like kata kata gombalan singkat - bikin baper - YouTube, 15 Kata-kata gombal saat PDKT, singkat, lucu dan bikin baper and also Kata-Kata Bijak: 35 KataKata Rayuan Gombal Romantis Paling Maut Buat. Here you go:

## Pantun Gombalan Romantis - Kumpulan Kata Motivasi

![Pantun Gombalan Romantis - Kumpulan Kata Motivasi](https://lh5.googleusercontent.com/proxy/cFlbgv7LDeeWwZYORqhWRBnja2_e40FwQezxPYR1ClxzmE8kTMBWQ3wmDVnuTXrEpi3d0qaQTkFXY1p2u2J2xDsgvhxwRkKshhS2Ja51c9teBoOK-gitosQSPXkN08o4=w1200-h630-p-k-no-nu "15 kata-kata gombal lucu bikin ngakak buat merayu (2021)")

<small>kititakata.blogspot.com</small>

Gombal baper gombalan rayuan pacar buat romantis islami laki teman senyum seyum sendiri liputan6 gebetan tersenyum pdkt singkat tebak tebakan. Gambar kata percakapan gombal

## Kata Bijak Singkat Lucu Cinta | QWERTY

![Kata Bijak Singkat Lucu Cinta | QWERTY](https://www.kutipkata.com/wp-content/uploads/2017/05/k-10-00_kata-kata-kecewa-untuk-seseorang_kutipan-anonim_800x450_dp-min.jpg "Romantis gombal")

<small>qwerty.co.id</small>

20 kata-kata gombal yang bikin baper dan meleleh. Kata kata motivasi singkat kerja

## Kata Bijak Lucu Dan Singkat / 1001+ Kata Kata Bijak Singkat, Lucu

![Kata Bijak Lucu Dan Singkat / 1001+ Kata Kata Bijak Singkat, Lucu](https://cdn.en.wtf/wp-content/uploads/2019/03/katakataLucu-t82-1-768x825.jpg "Kata kata gombalan singkat")

<small>galeriarlintang.blogspot.com</small>

54+ terbaru kata lucu pendek singkat, kata lucu. Gombal singkat mantan

## Kata Mutiara Gombal Singkat | Kata-Kata Bijak

![Kata Mutiara Gombal Singkat | Kata-Kata Bijak](https://cdn.en.wtf/wp-content/uploads/2018/06/Kata-kata-Lucu-Paling-Gokil-Terbaru.jpg "Romantis kata kata gombal lucu bikin baper")

<small>bijak.content.id</small>

25 kata kata gombal buat pacar yang bisa dijadikan inspirasi. Gombal singkat mantan

## Kata-Kata Gombal Buat Pacar Tersayang Yang Bisa Bikin Si Dia Meleleh

![Kata-Kata Gombal buat Pacar Tersayang yang bisa Bikin Si Dia Meleleh](https://www.tobakonis.com/wp-content/uploads/2019/10/000063-02_kata-kata-gombal-buat-pacar-tersayang_boy-candra_800x450_cc0-min-300x169.jpg "Kata kata gombal untuk teman laki laki")

<small>www.tobakonis.com</small>

Kata kata romantis lucu singkat : 120+ kata kata gombal lucu &amp; romantis. Kata kata gombal lucu singkat

## Kata Kata Motivasi Inggris Terjemahan - Contoh Tiup

![Kata Kata Motivasi Inggris Terjemahan - Contoh Tiup](https://2.bp.blogspot.com/-oCil0p3SJHM/Uv4CXkpKe0I/AAAAAAAAHkg/NPcTGbj3Pp0/w1200-h630-p-k-no-nu/Kumpulan+Kata+Kata+Lucu+2015.jpg "Romantis kata kata gombal lucu bikin baper")

<small>contohtiup.blogspot.com</small>

Kata mutiara gombal singkat. 25 kata kata gombal buat pacar yang bisa dijadikan inspirasi

## Kata Kata Gombal Buat Pacar Tersayang Singkat

![Kata Kata Gombal Buat Pacar Tersayang Singkat](https://www.toplucu.com/wp-content/uploads/2018/04/kata-01_kata-kata-gombal-lucu-buat-pacar_sandal-jepit_800x450_cc0-min.jpg "Kata-kata gombal buat pacar tersayang yang bisa bikin si dia meleleh")

<small>www.walpaperlist.com</small>

Pacar gombal tersayang jauh romantis baper meleleh. Gombal singkat mutiara

## Kata Kata Gombal Buat Pacar Tersayang Singkat

![Kata Kata Gombal Buat Pacar Tersayang Singkat](https://www.posbagus.com/wp-content/uploads/2019/02/000123-02_kata-kata-gombal-buat-pacar_payung-teduh_800x450_cc0-min.jpg "Gombal rayuan romantis maut pacar katakata tambah singkat gombalin")

<small>www.walpaperlist.com</small>

Kata mutiara gombal singkat. Kata kata gombal pdkt

## Romantis Kata Kata Gombal Lucu Bikin Baper | Portal Informasi Singkat

![Romantis Kata Kata Gombal Lucu Bikin Baper | Portal Informasi Singkat](https://lh5.googleusercontent.com/proxy/GkFFoR1SEPGImFm-zlECemCvr77mXUaRPyVcaZ4ewQNp03wSmCUIYgmRhomfuL1rsKor-2xxJo8oolVqlf-s5suWMe0XgZArQ5gIJEVYX_mNPwyoNdUjGEQjoFUge6lCC32t2gDx3ZRpo9c2TMR5_OD5iyGG3N5qgbkgV1llSOxVWnwVWNah8VaVHZUxM6WyxB5sabzdowsTwORK1_8A2w=w1200-h630-p-k-no-nu "25 kata kata gombal buat pacar yang bisa dijadikan inspirasi")

<small>suingkat.blogspot.com</small>

54+ terbaru kata lucu pendek singkat, kata lucu. Singkat mutiara

## Kata Mutiara Gombal Singkat | Kata-Kata Bijak

![Kata Mutiara Gombal Singkat | Kata-Kata Bijak](https://cdn.en.wtf/wp-content/uploads/2018/06/gambar-kata-kata-romantis-untuk-pacar-630x380.jpg "Kata mutiara gombal singkat")

<small>bijak.content.id</small>

Kata-kata bijak: 35 katakata rayuan gombal romantis paling maut buat. Kata bijak lucu dan singkat / 1001+ kata kata bijak singkat, lucu

## Kata Mutiara Gombal Singkat | Kata-Kata Bijak

![Kata Mutiara Gombal Singkat | Kata-Kata Bijak](https://cdn.en.wtf/wp-content/uploads/2018/06/Kata-Bijak-Kristen-Atau-Kristiani-19.jpg "Motivasi bijak singkat semangat mutiara kutipkata kata2 romantis penyemangat perjuangan sharifah astralis menghianati ruangtanya sukses wanto irwanto inspirasi buat penuh")

<small>bijak.content.id</small>

Kata mutiara gombal singkat. Singkat mutiara

## Gombalan Buat Doi - House Pdf

![Gombalan Buat Doi - House Pdf](https://4.bp.blogspot.com/-kn6ySQ3XJig/Wf4JkNDtRQI/AAAAAAAAAk0/kQy3vl7VX24mC45dcC5EUgDDG1zEcBg1wCLcBGAs/s1600/5.%2Bkata%2Bgombal%2B%2528zminga%2529.jpg "Kata mutiara gombal singkat")

<small>housepdfs.blogspot.com</small>

Kata kata bijak arti perasaan. Kata mutiara gombal singkat

## Kata Kata Lucu Yang Cocok Buat Status Fb - Contohisme

![Kata Kata Lucu Yang Cocok Buat Status Fb - Contohisme](https://lh3.googleusercontent.com/proxy/Iin8hg-BcUzPSvyrEUJXzFZJRZPs42Ek3lVWWQRxM5XGi9ii8GVHqY8IlVIkYDjIcWZgfT0npuoIWFdWOFhw70qC7dBmfzJK-J5bkhdlGEIDVyaK-vhidZmwWkh-weE-hJLTT9MmoQbNbNHni6wLzd_Bel1nxY_jF8-rMrZamzJuVLusYcS33i6vA9dp=w1200-h630-p-k-no-nu "Kata mutiara gombal singkat")

<small>contohisme.blogspot.com</small>

Kata mutiara gombal singkat. Pacar gombal bijak singkat kutipkata ulang sindiran tersayang peka hendrik zarry islami kekasih ngantuk berat biar dirumah suka pisang ratusan

## 15 Kata-Kata Gombal Lucu Bikin Ngakak Buat Merayu (2021) | PosKata

![15 Kata-Kata Gombal Lucu Bikin Ngakak buat Merayu (2021) | PosKata](https://www.poskata.com/wp-content/uploads/2020/06/000158-02_kata-kata-gombal-lucu-bikin-ngakak_kata-gombalan-lucu_800x450_cc0-min.jpg "54+ terbaru kata lucu pendek singkat, kata lucu")

<small>www.poskata.com</small>

Kata bijak singkat lucu cinta. 15 kata-kata gombal lucu bikin ngakak buat merayu (2021)

## Kata Mutiara Gombal Singkat | Kata-Kata Bijak

![Kata Mutiara Gombal Singkat | Kata-Kata Bijak](https://cdn.en.wtf/wp-content/uploads/2018/06/Gambar-Foto-Kata-Kata-Lucu-Terbaru-2.jpg "Kata mutiara gombal singkat")

<small>bijak.content.id</small>

Kata kata gombal buat pacar tersayang singkat. Kata-kata bijak: 35 katakata rayuan gombal romantis paling maut buat

## Kata Mutiara Gombal Singkat | Kata-Kata Bijak

![Kata Mutiara Gombal Singkat | Kata-Kata Bijak](https://cdn.en.wtf/wp-content/uploads/2018/06/gambar-motivasi-hidup-sukses.jpg "Singkat pendek cerita jenaka bugis dewasa katakatasmsyoko motivasi")

<small>bijak.content.id</small>

Kata mutiara gombal singkat. Kata kata gombal untuk teman laki laki

## Kata Kata Gombalan Singkat - Bikin Baper - YouTube

![kata kata gombalan singkat - bikin baper - YouTube](https://i.ytimg.com/vi/U78pwaBv79g/hqdefault.jpg "Kata bijak lucu dan singkat / 1001+ kata kata bijak singkat, lucu")

<small>www.youtube.com</small>

Kata mutiara gombal singkat. 54+ terbaru kata lucu pendek singkat, kata lucu

## 54+ Terbaru Kata Lucu Pendek Singkat, Kata Lucu

![54+ Terbaru Kata Lucu Pendek Singkat, Kata Lucu](https://1.bp.blogspot.com/-Cf7bZYpK6J4/VWE83WSae3I/AAAAAAAAC4E/of1Jj5pJDWQ/s1600/kata25252Bkata25252Blucu-tahpedia.jpg "Kata gombal pacar gombalan ketawa bahagia")

<small>katacintay.blogspot.com</small>

Gombal baper bikin tobakonis lucu romantis meleleh. Kata mutiara gombal singkat

## Kata Kata Bijak Arti Perasaan - Guratoh

![Kata Kata Bijak Arti Perasaan - Guratoh](https://lh6.googleusercontent.com/proxy/Jo96WgphxQIHxdEGhKq4ZWO5McP6zP3fikIqXLsHFUmtCfSQVSjDUAZELVfBc8eMv46ZIugovfXa0olfV_qjCGW0MhIN7nF4Drew7jcgr76GyppMr3IM3PzHKf-ASedcD5oTBWzbFGUj5ISAypGez1LY5g=w1200-h630-p-k-no-nu "75 kata kata keren buat caption ig, status fb, dan story media sosialmu")

<small>guratoh.blogspot.com</small>

Pacar gombal lucu mutiara gombalan inspiratif kalimat tersayang lemas berdaya jurus maut singkat. Bijak rohani mutiara alkitab kristiani singkat semangat gombal motivasi tuhan kehidupan kecewa kesabaran tuk jalani penyemangat suparman tertinggi yesus dewasa

## Kata Kata Romantis Lucu Singkat : 120+ Kata Kata Gombal Lucu &amp; Romantis

![Kata Kata Romantis Lucu Singkat : 120+ Kata Kata Gombal Lucu &amp; Romantis](https://i.ytimg.com/vi/En1NFlhyEas/maxresdefault.jpg "Kata mutiara gombal singkat")

<small>erikgambar.blogspot.com</small>

Gombal rayuan romantis maut pacar katakata tambah singkat gombalin. Kata kata bijak arti perasaan

## 25 Kata Kata Gombal Buat Pacar Yang Bisa Dijadikan Inspirasi | KutipKata

![25 Kata Kata Gombal Buat Pacar yang Bisa Dijadikan Inspirasi | KutipKata](https://www.kutipkata.com/wp-content/uploads/2017/08/k-29-00_kata-kata-gombal-buat-pacar_zarry-hendrik_800x450_cc0-min-768x432.jpg "Kata kata gombal untuk teman laki laki")

<small>www.kutipkata.com</small>

Lucu ngakak bikin gokil bijak mutiara singkat kocak abis galau terlengkap ketawa oi cerita motivasi ktawa populer tulisan katapos jorok. Kata-kata gombal buat pacar tersayang yang bisa bikin si dia meleleh

## Kata Mutiara Gombal Singkat | Kata-Kata Bijak

![Kata Mutiara Gombal Singkat | Kata-Kata Bijak](https://cdn.en.wtf/wp-content/uploads/2018/06/kata-kata-gombal-cinta-1-630x380.jpg "Kata-kata gombal buat pacar tersayang yang bisa bikin si dia meleleh")

<small>bijak.content.id</small>

75 kata kata keren buat caption ig, status fb, dan story media sosialmu. Kata kata motivasi singkat kerja

## Kata Kata Gombal Lucu Singkat - KATABAKU

![Kata Kata Gombal Lucu Singkat - KATABAKU](https://lh5.googleusercontent.com/proxy/Cm2LxYIKhX9lQTdhdbolaGq5FLNWGoFBm4HPrZuqefVYXjbFWLH80brX0QthsUJm1W4xmaKb044jq8z3uq4dlV2S70hvF08TNOMRL1GRU0wZqxVOI2kWqiscJQ=w1200-h630-p-k-no-nu "Singkat mutiara")

<small>katakuba.blogspot.com</small>

54+ terbaru kata lucu pendek singkat, kata lucu. Gombal singkat mutiara

## Gambar Kata Percakapan Gombal - Kata Lawak

![Gambar Kata Percakapan Gombal - Kata Lawak](https://lh3.googleusercontent.com/proxy/3SHO_Ti47fTWpNJ6165H2WjkOXvgGgh2WeQes5LqGvYb4URjq8_pdUURilrPIrQ1YKyPA7HJuUGJtJesowzHZfERc9vDOdA-2oktlP8bLogcGODvuwidvgkQ=w1200-h630-p-k-no-nu "Kata mutiara gombal singkat")

<small>katalawakku.blogspot.com</small>

Kata kata gombal untuk teman laki laki. Bijak rohani mutiara alkitab kristiani singkat semangat gombal motivasi tuhan kehidupan kecewa kesabaran tuk jalani penyemangat suparman tertinggi yesus dewasa

## Kata Kata Gombal Untuk Teman Laki Laki - Status Baper Terkini

![Kata Kata Gombal Untuk Teman Laki Laki - Status Baper Terkini](https://lh5.googleusercontent.com/proxy/TjtmZpRhWoovCDPk8mvj4kTGExjiPwNyiwF1b5oDlARaD4jhhJrtF8rpwxIlu3luyT-nSK_a-fqpIqwG81HFnzzC8rlhh938gLR2LpqQewDVUFIYCWawPXeSIMw427V59UxJ8lPnXG-x21DcUebhyLqI0Wk7MCsWsK7gOg49hWLvETTX8LMXMZ46BqYygPGXtP-HQrgepliAqJOKzdNXcj8Qps785LQEEjbDYreiM_vbuZpv3TqHl9k6frNXdtYHZujcMHFOh-Y24D8vkWK2Ixet4dNFOSrw7P3XgQ8OgKJQQeLyhIunvzYB9ffKck5ML6MI8TI3=w1200-h630-p-k-no-nu "Lucu ngakak bikin gokil bijak mutiara singkat kocak abis galau terlengkap ketawa oi cerita motivasi ktawa populer tulisan katapos jorok")

<small>statuskini.blogspot.com</small>

25 kata kata gombal buat pacar yang bisa dijadikan inspirasi. Kata mutiara gombal singkat

## Kata Kata Motivasi Singkat Kerja - Auratoh

![Kata Kata Motivasi Singkat Kerja - Auratoh](https://lh5.googleusercontent.com/proxy/Uk8ksPEK9ynGvxhv3QZQWCAGuWcrBnxlIuJolQH0-LuFUFQB1l0-cEu2FwA53U_OyohObxRYxyW36gdTNNTFw9IGsWFyuDOgZJx_jUCaWb8K_3UyjEF52rSIUXcDD_UMe7I3mjHFSz5fqkSa_-5VDCLEenWHzZPWOfDiD6Z45L9FDvLmnSCuAhEiLjBhSMN0NumcE4R1=w1200-h630-p-k-no-nu "Gombal rayuan gombalan percakapan lucunya romantis kocaknya tersipu malu sipu brilio pengen nikah")

<small>auratoh.blogspot.com</small>

Singkat mutiara. Kata mutiara gombal singkat

## Kata Mutiara Gombal Singkat | Kata-Kata Bijak

![Kata Mutiara Gombal Singkat | Kata-Kata Bijak](https://cdn.en.wtf/wp-content/uploads/2018/06/Kata-Kata-Cinta-Lucu-Gokil-Singkat.jpg "Kata gombal pacar gombalan ketawa bahagia")

<small>bijak.content.id</small>

Kata kata gombal pdkt. Kata mutiara gombal singkat

## Kata-Kata Bijak: 35 KataKata Rayuan Gombal Romantis Paling Maut Buat

![Kata-Kata Bijak: 35 KataKata Rayuan Gombal Romantis Paling Maut Buat](https://4.bp.blogspot.com/-em0jG-N6uWc/Wj4MdePOEWI/AAAAAAAAF0Y/C5pADmYczvE9WnjiZRMEAylGR9L-AEmogCLcBGAs/s1600/kata-kata-rayuan-gombal.jpg "Gombal baper bikin tobakonis lucu romantis meleleh")

<small>kata-bijak001.blogspot.com</small>

Kata kata gombal bikin baper lewat chat. Romantis kata kata gombal lucu bikin baper

## Kata Gombal Romantis Bikin Baper Kata Kata Cinta Islami - Audit Kinerja

![Kata Gombal Romantis Bikin Baper Kata Kata Cinta Islami - Audit Kinerja](https://titikdua.net/wp-content/uploads/2019/02/Kumpulan-Kata-Kata-Gombal.jpg "Lucu ngakak bikin gokil bijak mutiara singkat kocak abis galau terlengkap ketawa oi cerita motivasi ktawa populer tulisan katapos jorok")

<small>auditkinerja.com</small>

Pantun gombalan romantis. Pacar gombal tersayang jauh romantis baper meleleh

## Kata Kata Gombal Pdkt - Herotoh

![Kata Kata Gombal Pdkt - Herotoh](https://image.winudf.com/v2/image/Y29tLmthdGFnb21iYWwuYW5udWl0eXNldHRsZW1lbnRfc2NyZWVuXzJfMTU0MDEyMTU0M18wNjA/screen-2.jpg?h=800&amp;fakeurl=1&amp;type=.jpg "Kata kata gombal buat pacar tersayang singkat")

<small>herotoh.blogspot.com</small>

Kata kata gombal untuk teman laki laki. Kata kata gombal pdkt

## 75 Kata Kata Keren Buat Caption IG, Status FB, Dan Story Media Sosialmu

![75 Kata Kata Keren Buat Caption IG, Status FB, dan Story Media Sosialmu](https://i0.wp.com/titikdua.net/wp-content/uploads/2019/08/Kata-Kata-Keren-Gombal-800x800.png "Gombal baper bikin tobakonis lucu romantis meleleh")

<small>titikdua.net</small>

Kata mutiara gombal singkat. Gombal rayuan gombalan percakapan lucunya romantis kocaknya tersipu malu sipu brilio pengen nikah

## 15 Kata-kata Gombal Saat PDKT, Singkat, Lucu Dan Bikin Baper

![15 Kata-kata gombal saat PDKT, singkat, lucu dan bikin baper](https://cdn-brilio-net.akamaized.net/news/2019/10/01/171546/15-kata-kata-gombal-saat-pdkt-singkat-lucu-dan-bikin-baper-1910018.jpg "Gombal singkat mutiara")

<small>www.brilio.net</small>

Kata mutiara cocok bijak bergambar. Kata gombal pacar gombalan ketawa bahagia

## Kata Kata Gombal Buat Pacar Tersayang Singkat

![Kata Kata Gombal Buat Pacar Tersayang Singkat](https://www.kepogaul.com/wp-content/uploads/2018/04/000142-04_kata-kata-gombal-lucu-buat-pacar_pacaran_800x450_cc0-min.jpg "Kata kata gombal buat pacar tersayang singkat")

<small>www.walpaperlist.com</small>

75 kata kata keren buat caption ig, status fb, dan story media sosialmu. Kata kata gombal untuk teman laki laki

## 20 Kata-Kata Gombal Yang Bikin Baper Dan Meleleh | Tobakonis

![20 Kata-Kata Gombal yang Bikin Baper dan Meleleh | Tobakonis](https://www.tobakonis.com/wp-content/uploads/2019/11/00068-02_kata-kata-gombal-bikin-baper_sama-kamu_800x450_cc0-min-768x432.jpg "Pacar gombal tersayang jauh romantis baper meleleh")

<small>www.tobakonis.com</small>

Pacar gombal bijak singkat kutipkata ulang sindiran tersayang peka hendrik zarry islami kekasih ngantuk berat biar dirumah suka pisang ratusan. Kata kata motivasi inggris terjemahan

## Kata Kata Gombal Bikin Baper Lewat Chat - KATABAKU

![Kata Kata Gombal Bikin Baper Lewat Chat - KATABAKU](https://lh6.googleusercontent.com/proxy/u8biNpfzLRroj1cRcEgpyBcCuwfdoMAV9D8MQ2SmWVDGFM2Ht2b1nQ4fEruY-8fKAgVQo2s2Mc4I3hb7ah-Ic8A57r0C0tC2=w1200-h630-pd "Gombal rayuan romantis maut pacar katakata tambah singkat gombalin")

<small>katakuba.blogspot.com</small>

Kata mutiara gombal singkat. 20 kata-kata gombal yang bikin baper dan meleleh

Kata kata gombal pdkt. 25 kata kata gombal buat pacar yang bisa dijadikan inspirasi. Gombal singkat mutiara
